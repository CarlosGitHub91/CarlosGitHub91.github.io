import java.net.*;
import java.io.*;

public class Coche {

	public static void main(String args[]) throws IOException {
		try (
				Socket socket = new Socket("localhost", 60000)) {
                System.out.println("Ciente conectado desde Socket "+ socket.toString());
                System.out.println("Hash MD5 verificado. Los datos recibidos son correctos.");   
			// CREE FLUXOS D'ENTRADA I EIXIDA
			PrintWriter feixida = new PrintWriter(socket.getOutputStream(), true);
			BufferedReader fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			// FLUX PER A L'ENTRADA PER TECLAT
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

			String cadena, cadenaRebuda;

			System.out.println("Introduce el color del coche y lo devuelve en color rojo: ");
			do {
				cadena = in.readLine();
				feixida.println(cadena);
				cadenaRebuda = fentrada.readLine();
				System.out.println("Coche recibido: Toyota Corolla " + cadena + "\n" + cadenaRebuda);

			} while (!(cadena.contentEquals("*")));

			System.out.println("Fi comunicació");

			// TANQUE FLUXOS I SOCKET
			feixida.close();
			fentrada.close();
			in.close();
			socket.close();
		}
	}
}

