public class Benjamin extends Thread {
    public Campo c;

    public Benjamin(Campo campo) {
        this.c = campo;
    }

    public void run() {
        while (true) {
            plantar();
            try {
                sleep(3000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    public synchronized void plantar() {
        for (int i = 0; i < 2; i++) {
            if (c.getflores().contains(false)) {
                int posicion = c.getflores().indexOf(false);
                c.setflores(posicion, true);
                System.out.println("Flores plantadas en " + posicion);
            }
        }

    }

}