import java.util.ArrayList;

public class Campo {
    ArrayList<Boolean> flores =  new ArrayList<>();
    public Campo(ArrayList<Boolean> flores){
        this.flores = flores;
    }
    public ArrayList getflores(){
        return this.flores;
    }
    public void setflores(int p ,boolean flor){
        this.flores.set(p, flor);
    }
}