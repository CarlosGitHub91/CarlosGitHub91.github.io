import java.util.ArrayList;

public class Principal {

    public static void main(String[] args) {
        ArrayList<Boolean>list = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            list.add(false);
        }
        Campo c = new Campo(list);
        Benjamin b = new Benjamin(c);
        Alicia a = new Alicia(c);
        b.start();
        a.start();
    }
}
