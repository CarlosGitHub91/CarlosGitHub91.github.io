public class Alicia extends Thread {
    public Campo c;

    public Alicia(Campo campo) {
        this.c = campo;
    }

    public void run() {
        while (true) {
            recoger();
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }

    public synchronized void recoger() {
        if (c.getflores().contains(true)) {
            int posicion = c.getflores().indexOf(true);
            c.setflores(posicion, false);
            System.out.println("Flores recogidas en " + posicion);
        }

    }
}
