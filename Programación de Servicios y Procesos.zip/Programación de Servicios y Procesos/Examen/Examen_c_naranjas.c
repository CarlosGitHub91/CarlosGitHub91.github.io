#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <signal.h>

void gestio_padre(int sig){
    printf("Hijo sal!\n");
}

void gestio_hijo(int sig){
    printf("Hijo recibe señal!\n");
}
int main(){
    pid_t pid_padre, pid_hijo;
    pid_padre = getpid();
    pid_hijo = fork();
    int cont = 0;

    switch (pid_hijo)
    {
    case -1:
        printf("Error al crear el proceso hijo...\n");
        exit(-1);
        break;
    case 0:
        signal(SIGUSR1,gestio_hijo);
        signal(SIGUSR2,gestio_padre);
        while(cont<2){
            pause();
            cont++;
        }
        exit(0);
    default:
    print("Hijo escondete\n")
    kill(pid_hijo,SIGUSR1);
    sleep(2);//Pequeña espera para asegurar que el hijo reciba la señal SIGUSR1
    wait(NULL);
    printf("Ha sido muy divertido\n");
        break;
    }
}