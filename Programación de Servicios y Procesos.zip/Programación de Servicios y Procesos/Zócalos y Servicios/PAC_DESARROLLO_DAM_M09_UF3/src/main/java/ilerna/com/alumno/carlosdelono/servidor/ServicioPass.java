package ilerna.com.alumno.carlosdelono.servidor;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ServicioPass {

    private static final SecureRandom random = new SecureRandom();

    public String generarContraseña(int numMayusculas, int numMinusculas, int numDigitos, int numCaracteresEspeciales) {
        StringBuilder contraseña = new StringBuilder();

        List<Character> caracteres = new ArrayList<>();

        // Agregar caracteres según los requisitos
        for (int i = 0; i < numMayusculas; i++) {
            caracteres.add(generarCaracterAleatorio('A', 'Z'));
        }
        for (int i = 0; i < numMinusculas; i++) {
            caracteres.add(generarCaracterAleatorio('a', 'z'));
        }
        for (int i = 0; i < numDigitos; i++) {
            caracteres.add(generarCaracterAleatorio('0', '9'));
        }
        for (int i = 0; i < numCaracteresEspeciales; i++) {
            caracteres.add(generarCaracterEspecial());
        }

        // Mezclar los caracteres en orden aleatorio
        Collections.shuffle(caracteres, random);

        // Construir la contraseña
        for (char c : caracteres) {
            contraseña.append(c);
        }

        return contraseña.toString();
    }

    private char generarCaracterAleatorio(char inicio, char fin) {
        return (char) (random.nextInt(fin - inicio + 1) + inicio);
    }

    private char generarCaracterEspecial() {
        String caracteresEspeciales = "!@#$%^&*()_+[]{}|;:,.<>?";
        return caracteresEspeciales.charAt(random.nextInt(caracteresEspeciales.length()));
    }
}
