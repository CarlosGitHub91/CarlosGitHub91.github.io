package ilerna.com.alumno.carlosdelono.servidor;

public class MainServidor {
    public static void main(String[] args) {
        Servidor servidor = new Servidor();
        servidor.iniciar();
    }
}