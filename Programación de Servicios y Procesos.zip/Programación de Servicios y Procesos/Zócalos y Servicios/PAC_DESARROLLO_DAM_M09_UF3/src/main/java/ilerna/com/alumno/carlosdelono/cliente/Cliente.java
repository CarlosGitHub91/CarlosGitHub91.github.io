package ilerna.com.alumno.carlosdelono.cliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class Cliente {

    private static final String HOST = "localhost";
    private static final int PORT = 4321;

    public void conectar() {
        try (Socket socket = new Socket(HOST, PORT);
                BufferedReader entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter salida = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader consola = new BufferedReader(new InputStreamReader(System.in))) {

            // Inicia la comunicación con el servidor
            System.out.println("Cliente- Conectando al servidor...");
            System.out.println("Cliente- " + entrada.readLine()); // Recibe el mensaje de bienvenida del servidor

            // Responde al servidor con el nombre del cliente
            System.out.print("Cliente- ");
            String nombreCliente = consola.readLine();
            salida.println(nombreCliente);

            // Recibe y muestra el mensaje de bienvenida del servidor
            System.out.println("Cliente- " + entrada.readLine());
            System.out.println("Cliente- " + entrada.readLine());

            // Recibir todas las preguntas del servidor
            for (int i = 0; i < 4; i++) {
                String pregunta = entrada.readLine();
                System.out.println("Cliente- " + pregunta);
                System.out.print("Cliente- ");
                String respuesta = consola.readLine();
                salida.println(respuesta);
            }

            // Leer la respuesta del servidor sobre la generación de contraseña
            String respuestaGenerarContraseña = entrada.readLine();
            System.out.println("Cliente- " + respuestaGenerarContraseña);

            // Verificar si el servidor solicita generar una contraseña
            if (respuestaGenerarContraseña.contains("La longitud de la contraseña que se va a generar es")) {
                // Leer la respuesta del cliente sobre si desea generar la contraseña
                System.out.println("Cliente- ¿Quieres generar una contraseña ahora? [si/ no]");
                String respuesta = consola.readLine();
                salida.println(respuesta);

                // Si la respuesta del cliente es 'si', leer la contraseña generada del servidor
                if (respuesta.equalsIgnoreCase("si")) {
                    String contraseñaGenerada = entrada.readLine();
                    System.out.println("Cliente- " + contraseñaGenerada);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
