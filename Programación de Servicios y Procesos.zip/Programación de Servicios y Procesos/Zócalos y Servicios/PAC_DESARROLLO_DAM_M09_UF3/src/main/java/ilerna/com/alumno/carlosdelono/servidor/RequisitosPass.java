package ilerna.com.alumno.carlosdelono.servidor;

public class RequisitosPass {

    public boolean validarRequisitos(String contraseña, int numMayusculas, int numMinusculas, int numDigitos,
            int numCaracteresEspeciales) {
        // Contadores para los tipos de caracteres
        int contadorMayusculas = 0;
        int contadorMinusculas = 0;
        int contadorDigitos = 0;
        int contadorCaracteresEspeciales = 0;

        // Recorrer la contraseña para contar cada tipo de caracter
        for (char c : contraseña.toCharArray()) {
            if (Character.isUpperCase(c)) {
                contadorMayusculas++;
            } else if (Character.isLowerCase(c)) {
                contadorMinusculas++;
            } else if (Character.isDigit(c)) {
                contadorDigitos++;
            } else {
                contadorCaracteresEspeciales++;
            }
        }

        // Validar los requisitos
        boolean cumpleMayusculas = contadorMayusculas >= numMayusculas;
        boolean cumpleMinusculas = contadorMinusculas >= numMinusculas;
        boolean cumpleDigitos = contadorDigitos >= numDigitos;
        boolean cumpleCaracteresEspeciales = contadorCaracteresEspeciales >= numCaracteresEspeciales;

        // Retorna true si todos los requisitos se cumplen, false en caso contrario
        return cumpleMayusculas && cumpleMinusculas && cumpleDigitos && cumpleCaracteresEspeciales;
    }
}
