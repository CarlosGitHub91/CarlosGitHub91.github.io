package ilerna.com.alumno.carlosdelono.servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

    private static final int PORT = 4321;

    public void iniciar() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Servidor- Servidor arrancado");
            System.out.println("Servidor- Esperando al cliente...");

            while (true) {
                try (Socket clienteSocket = serverSocket.accept()) {
                    System.out.println("Servidor- Cliente conectado desde " + clienteSocket.getInetAddress());
                    // Procesar la conexión con el cliente
                    procesarConexionCliente(clienteSocket);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void procesarConexionCliente(Socket clienteSocket) {
        try (BufferedReader entrada = new BufferedReader(new InputStreamReader(clienteSocket.getInputStream()));
                PrintWriter salida = new PrintWriter(clienteSocket.getOutputStream(), true)) {

            // Servidor pregunta el nombre del cliente
            salida.println("Servidor- ¿Cómo te llamas?");
            String nombreCliente = entrada.readLine();
            salida.println("Servidor- Te doy la bienvenida, " + nombreCliente);
            System.out.println("Servidor- Nombre del cliente: " + nombreCliente);

            salida.println("Servidor- Voy a solicitarte distintos requisitos para la contraseña que voy a generar.");

            // Solicitar y enviar todas las preguntas al cliente
            String[] preguntas = {
                    "Cuántas mayúsculas debe tener la contraseña?",
                    "Cuántas minúsculas debe tener la contraseña?",
                    "Cuántos dígitos debe tener la contraseña?",
                    "Cuántos caracteres especiales debe tener la contraseña?"
            };

            // Enviar todas las preguntas al cliente
            for (String pregunta : preguntas) {
                salida.println(pregunta);
            }

            // Leer las respuestas del cliente
            int[] respuestas = new int[preguntas.length];
            for (int i = 0; i < preguntas.length; i++) {
                respuestas[i] = Integer.parseInt(entrada.readLine());
            }
            System.out
                    .println("Servidor- PasswordReqs: " + " mayusculas=" + respuestas[0] + ", minusculas"
                            + respuestas[1] + ", digitos"
                            + respuestas[2] + ", caracteresEspeciales" + respuestas[3]);

            // Generar y enviar contraseña al cliente
            String contraseñaGenerada = generarContraseña(respuestas);
            salida.println(
                    "Servidor- La longitud de la contraseña que se va a generar es de " + contraseñaGenerada.length()
                            + " caracteres.");
            System.out.println("Servidor- Se ha enviado la longitud de la contraseña al cliente");

            // Esperar la respuesta del cliente sobre la generación de contraseña
            String respuestaGenerarContraseña = entrada.readLine();
            if (respuestaGenerarContraseña.equalsIgnoreCase("si")) {
                salida.println("Servidor- La contraseña generada es: " + contraseñaGenerada);
                System.out.println("Servidor- Se ha enviado la contraseña al cliente");
            } else {
                salida.println("Servidor- No se generará contraseña.");
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

    private String generarContraseña(int[] respuestas) {
        try {
            int numMayusculas = respuestas[0];
            int numMinusculas = respuestas[1];
            int numDigitos = respuestas[2];
            int numCaracteresEspeciales = respuestas[3];

            StringBuilder contraseña = new StringBuilder();
            String mayusculas = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            String minusculas = "abcdefghijklmnopqrstuvwxyz";
            String digitos = "0123456789";
            String especiales = "!@#$%^&*()-_=+[{]}|;:,<.>/?";

            // Generar caracteres aleatorios
            for (int i = 0; i < numMayusculas; i++) {
                contraseña.append(mayusculas.charAt((int) (Math.random() * mayusculas.length())));
            }
            for (int i = 0; i < numMinusculas; i++) {
                contraseña.append(minusculas.charAt((int) (Math.random() * minusculas.length())));
            }
            for (int i = 0; i < numDigitos; i++) {
                contraseña.append(digitos.charAt((int) (Math.random() * digitos.length())));
            }
            for (int i = 0; i < numCaracteresEspeciales; i++) {
                contraseña.append(especiales.charAt((int) (Math.random() * especiales.length())));
            }

            // Mezclar los caracteres en orden aleatorio
            char[] contraseñaArray = contraseña.toString().toCharArray();
            for (int i = contraseñaArray.length - 1; i > 0; i--) {
                int indiceAleatorio = (int) (Math.random() * (i + 1));
                char temp = contraseñaArray[indiceAleatorio];
                contraseñaArray[indiceAleatorio] = contraseñaArray[i];
                contraseñaArray[i] = temp;
            }

            return new String(contraseñaArray);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return ""; // Devolver una cadena vacía en caso de error
        }
    }
}
