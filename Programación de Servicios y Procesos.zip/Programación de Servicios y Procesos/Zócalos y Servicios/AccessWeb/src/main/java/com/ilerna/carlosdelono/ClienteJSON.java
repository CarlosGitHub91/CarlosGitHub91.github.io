package com.ilerna.carlosdelono;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import java.nio.charset.Charset;

import org.json.JSONObject;

public class ClienteJSON {

	/**
	 * 
	 * @param url
	 * @return obtenemos la cadena del JSON de la URL que buscamos
	 * @throws IOException
	 */
	public String respuestaJSON(URL url) throws IOException {
		InputStream input = url.openStream();
		InputStreamReader isr = new InputStreamReader(input);
		BufferedReader reader = new BufferedReader(isr);
		StringBuilder json = new StringBuilder();
		int c;
		while ((c = reader.read()) != -1) {
			json.append((char) c);
		}
		return json.toString();
	}

	////////////////////////////////////////
	////////////////////////////////////////
	
	
	private String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}

	public JSONObject respuestaJSONLibrería(URL url) throws IOException {
		InputStream is = url.openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is, Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			JSONObject json = new JSONObject(jsonText);
			return json;
		} finally {
			is.close();
		}
	}

}
