/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package lacasadeallado;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Carlos
 */
public class Buscar extends javax.swing.JInternalFrame {

    Connection con;
    DefaultTableModel modelo;
    public Buscar() {
        initComponents();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Buscar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                      
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblReceta = new javax.swing.JTable();
        btnBuscar = new javax.swing.JButton();
        tfNomReceta = new javax.swing.JTextField();
        tfPersonas = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblPrecios = new javax.swing.JTable();
        lbPrecios = new javax.swing.JLabel();
        lbRecetas = new javax.swing.JLabel();
        tfUnidades = new javax.swing.JTextField();
        tfPrecioVenta = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        btnCalcular = new javax.swing.JButton();

        tblReceta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Ingrediente1", "Ingrediente2", "Ingrediente3", "Ingrediente4", "Ingrediente5", "Ingrediente6", "Ingrediente7", "Ingrediente8"
            }
        ));
        jScrollPane1.setViewportView(tblReceta);

        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        tfNomReceta.setText("Nombre de la Receta");
        tfNomReceta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNomRecetaActionPerformed(evt);
            }
        });

        tfPersonas.setText("Cantidad de Recetas");
        tfPersonas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPersonasActionPerformed(evt);
            }
        });

        tblPrecios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Coste plato/persona", "Coste receta", "Ganancia plato/persona", "Ganancia receta", "Precio al Cliente/persona", "Precio al Cliente"
            }
        ));
        jScrollPane2.setViewportView(tblPrecios);

        lbPrecios.setText("Precios");

        lbRecetas.setText("Recetas");

        tfUnidades.setText("Unidades por receta");
        tfUnidades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfUnidadesActionPerformed(evt);
            }
        });

        tfPrecioVenta.setText("Porcentaje de ganancia");
        tfPrecioVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPrecioVentaActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnCalcular.setText("Calcular");
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(317, 317, 317)
                                .addComponent(lbPrecios))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(168, 168, 168)
                                .addComponent(tfPersonas, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnBuscar)
                                .addGap(18, 18, 18)
                                .addComponent(btnEliminar))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(246, 246, 246)
                                .addComponent(tfNomReceta, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(315, 315, 315)
                                .addComponent(lbRecetas))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(174, 174, 174)
                                .addComponent(tfUnidades, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnCalcular)
                                .addGap(18, 18, 18)
                                .addComponent(tfPrecioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 277, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addComponent(jScrollPane2))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(lbRecetas)
                .addGap(18, 18, 18)
                .addComponent(tfNomReceta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBuscar)
                    .addComponent(tfPersonas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar))
                .addGap(18, 18, 18)
                .addComponent(lbPrecios)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfUnidades, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCalcular)
                    .addComponent(tfPrecioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(246, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        try {
            modelo = (DefaultTableModel)tblReceta.getModel();
            
            con = DriverManager.getConnection("jdbc:mysql://localhost/lacasadeallado","root","");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT Nombre_receta,Ingrediente1,Cantidad1*"+tfPersonas.getText()+",Ingrediente2,Cantidad2*"+tfPersonas.getText()+",Ingrediente3,Cantidad3*"+tfPersonas.getText()+",Ingrediente4,Cantidad4*"+tfPersonas.getText()+",Ingrediente5,Cantidad5*"+tfPersonas.getText()+",Ingrediente6,Cantidad6*"+tfPersonas.getText()+",Ingrediente7,Cantidad7*"+tfPersonas.getText()+",Ingrediente8,Cantidad8*"+tfPersonas.getText()+" FROM recetas WHERE recetas.Nombre_Receta LIKE('"+tfNomReceta.getText()+"')");
            
            if(rs.next()){
                do{
                    String[] cantidad = {rs.getString(3),rs.getString(5),rs.getString(7),rs.getString(9),rs.getString(11),rs.getString(13),rs.getString(15),rs.getString(17)};
                    String[] ingredientes = {rs.getString(2),rs.getString(4),rs.getString(6),rs.getString(8),rs.getString(10),rs.getString(12),rs.getString(14),rs.getString(16)};
                    modelo.addRow(ingredientes);
                    modelo.addRow(cantidad);
                }while(rs.next());
            }
        }catch (SQLException ex) {
            Logger.getLogger(Buscar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void tfNomRecetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNomRecetaActionPerformed
        tfNomReceta.setText("");
    }//GEN-LAST:event_tfNomRecetaActionPerformed

    private void tfPersonasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPersonasActionPerformed
        tfPersonas.setText("");
    }//GEN-LAST:event_tfPersonasActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int eliminartodo = tblReceta.getRowCount();
        for(int i = eliminartodo-1;i>=0;i--){
            modelo.removeRow(i);
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tfUnidadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfUnidadesActionPerformed
        tfUnidades.setText("");
    }//GEN-LAST:event_tfUnidadesActionPerformed

    private void tfPrecioVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPrecioVentaActionPerformed
        tfPrecioVenta.setText("");
    }//GEN-LAST:event_tfPrecioVentaActionPerformed

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        
        try{
            modelo = (DefaultTableModel)tblPrecios.getModel();
            
            con = DriverManager.getConnection("jdbc:mysql://localhost/lacasadeallado","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            /*ResultSet rs1 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad1/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente1;");
            ResultSet rs2 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad2/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente2;");
            ResultSet rs3 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad3/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente3;");
            ResultSet rs4 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad4/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente4;");
            ResultSet rs5 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad5/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente5;");
            ResultSet rs6 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad6/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente6;");
            ResultSet rs7 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad7/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente7;");
            ResultSet rs8 = stmt.executeQuery("SELECT (ingredientes.Precio*recetas.Cantidad8/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente8;");
            */float costereceta = 0;
            float costepersona = 0;
            float totalreceta = 0;
            float totalrecetapersona = 0;
            
            int a=1;
            
            while(a<=8){
                rs = stmt.executeQuery("SELECT ("+tfPersonas.getText()+"*ingredientes.Precio*recetas.Cantidad"+a+"/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente"+a+";");

                    while(rs.next()){
                        float precioingrediente = rs.getFloat(1);
                        costereceta += precioingrediente;       
                    }
                    a++;
            }
            String coste_receta = String.valueOf(costereceta);
            int b=1;
            
            while(b<=8){
                rs = stmt.executeQuery("SELECT ("+tfPersonas.getText()+"*ingredientes.Precio*recetas.Cantidad"+b+"/1000)/"+tfUnidades.getText()+" FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente"+b+";");

                    while(rs.next()){
                        float precioingrediente = rs.getFloat(1);
                        costepersona += precioingrediente;       
                    }
                    b++;
            }
            String coste_persona = String.valueOf(costepersona);
            
            int c=1;
            
            while(c<=8){
                rs = stmt.executeQuery("SELECT ("+tfPersonas.getText()+"*("+tfPrecioVenta.getText()+"/100)*ingredientes.Precio*recetas.Cantidad"+c+"/1000) FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente"+c+";");

                    while(rs.next()){
                        float precioingrediente = rs.getFloat(1);
                        totalreceta += precioingrediente;       
                    }
                    c++;
            }
            String total_receta = String.valueOf(totalreceta);
            
            int d=1;
            
            while(d<=8){
                rs = stmt.executeQuery("SELECT ("+tfPersonas.getText()+"*("+tfPrecioVenta.getText()+"/100)*ingredientes.Precio*recetas.Cantidad"+d+"/1000)/"+tfUnidades.getText()+" FROM ingredientes,recetas WHERE recetas.Nombre_Receta LIKE ('"+tfNomReceta.getText()+"') AND ingredientes.Ingrediente = recetas.Ingrediente"+d+";");

                    while(rs.next()){
                        float precioingrediente = rs.getFloat(1);
                        totalrecetapersona += precioingrediente;       
                    }
                    d++;
            }
            String total_receta_persona = String.valueOf(totalrecetapersona);
            float gananciareceta = totalreceta-costereceta;
            String ganancia_receta = String.valueOf(gananciareceta);
            float gananciarecetapersona = totalrecetapersona-costepersona;
            String ganancia_receta_persona = String.valueOf(gananciarecetapersona);
            String [] precio = {coste_persona,coste_receta,ganancia_receta_persona,ganancia_receta,total_receta_persona,total_receta};
            modelo.addRow(precio);
                
            
        }catch (SQLException ex) {
            Logger.getLogger(Buscar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnCalcularActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnCalcular;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbPrecios;
    private javax.swing.JLabel lbRecetas;
    private javax.swing.JTable tblPrecios;
    private javax.swing.JTable tblReceta;
    private javax.swing.JTextField tfNomReceta;
    private javax.swing.JTextField tfPersonas;
    private javax.swing.JTextField tfPrecioVenta;
    private javax.swing.JTextField tfUnidades;
    // End of variables declaration//GEN-END:variables
}
