/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package lacasadeallado;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Registrar extends javax.swing.JInternalFrame {

    Connection con;
    public Registrar() {
        initComponents();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Registraringrediente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jlRegistroReceta = new javax.swing.JLabel();
        tfNomReceta = new javax.swing.JTextField();
        tfIngrediente1 = new javax.swing.JTextField();
        tfIngrediente2 = new javax.swing.JTextField();
        tfIngrediente3 = new javax.swing.JTextField();
        tfIngrediente4 = new javax.swing.JTextField();
        tfIngrediente5 = new javax.swing.JTextField();
        tfIngrediente6 = new javax.swing.JTextField();
        tfIngrediente7 = new javax.swing.JTextField();
        tfIngrediente8 = new javax.swing.JTextField();
        tfCantidad6 = new javax.swing.JTextField();
        tfCantidad7 = new javax.swing.JTextField();
        tfCantidad8 = new javax.swing.JTextField();
        tfCantidad1 = new javax.swing.JTextField();
        tfCantidad2 = new javax.swing.JTextField();
        tfCantidad3 = new javax.swing.JTextField();
        tfCantidad4 = new javax.swing.JTextField();
        tfCantidad5 = new javax.swing.JTextField();
        btnRegistrar = new javax.swing.JButton();
        btnBorrar = new javax.swing.JButton();

        jlRegistroReceta.setText("Registro Recetas");

        tfNomReceta.setText("Nombre de la Receta");
        tfNomReceta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNomRecetaActionPerformed(evt);
            }
        });

        tfIngrediente1.setText("Ingrediente 1");
        tfIngrediente1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente1ActionPerformed(evt);
            }
        });

        tfIngrediente2.setText("Ingrediente 2");
        tfIngrediente2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente2ActionPerformed(evt);
            }
        });

        tfIngrediente3.setText("Ingrediente 3");
        tfIngrediente3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente3ActionPerformed(evt);
            }
        });

        tfIngrediente4.setText("Ingrediente 4");
        tfIngrediente4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente4ActionPerformed(evt);
            }
        });

        tfIngrediente5.setText("Ingrediente 5");
        tfIngrediente5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente5ActionPerformed(evt);
            }
        });

        tfIngrediente6.setText("Ingrediente 6");
        tfIngrediente6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente6ActionPerformed(evt);
            }
        });

        tfIngrediente7.setText("Ingrediente 7");
        tfIngrediente7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente7ActionPerformed(evt);
            }
        });

        tfIngrediente8.setText("Ingrediente 8");
        tfIngrediente8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIngrediente8ActionPerformed(evt);
            }
        });

        tfCantidad6.setText("Cantidad");
        tfCantidad6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad6ActionPerformed(evt);
            }
        });

        tfCantidad7.setText("Cantidad");
        tfCantidad7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad7ActionPerformed(evt);
            }
        });

        tfCantidad8.setText("Cantidad");
        tfCantidad8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad8ActionPerformed(evt);
            }
        });

        tfCantidad1.setText("Cantidad");
        tfCantidad1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad1ActionPerformed(evt);
            }
        });

        tfCantidad2.setText("Cantidad");
        tfCantidad2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad2ActionPerformed(evt);
            }
        });

        tfCantidad3.setText("Cantidad");
        tfCantidad3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad3ActionPerformed(evt);
            }
        });

        tfCantidad4.setText("Cantidad");
        tfCantidad4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad4ActionPerformed(evt);
            }
        });

        tfCantidad5.setText("Cantidad");
        tfCantidad5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCantidad5ActionPerformed(evt);
            }
        });

        btnRegistrar.setText("Registrar");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });

        btnBorrar.setText("Borrar");
        btnBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(tfNomReceta, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(167, 167, 167))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tfIngrediente1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfIngrediente2, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfIngrediente3, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfIngrediente4, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfIngrediente5, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfIngrediente6, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfIngrediente7, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfIngrediente8, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(86, 86, 86)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tfCantidad1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCantidad2, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCantidad3, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCantidad4, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCantidad5, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCantidad6, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCantidad7, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfCantidad8, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(231, 231, 231)
                        .addComponent(jlRegistroReceta))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addComponent(btnRegistrar)
                        .addGap(44, 44, 44)
                        .addComponent(btnBorrar)))
                .addContainerGap(114, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jlRegistroReceta)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfNomReceta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tfIngrediente1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfIngrediente2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfIngrediente3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfIngrediente4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfIngrediente5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfIngrediente6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfIngrediente7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfIngrediente8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnRegistrar)
                            .addComponent(btnBorrar))
                        .addGap(10, 10, 10))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfCantidad1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(tfCantidad2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCantidad3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCantidad4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCantidad5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCantidad6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCantidad7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tfCantidad8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(62, 62, 62)))
                .addContainerGap(86, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfIngrediente2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente2ActionPerformed
        tfIngrediente2.setText("");
    }//GEN-LAST:event_tfIngrediente2ActionPerformed

    private void tfIngrediente5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente5ActionPerformed
        tfIngrediente5.setText("");
    }//GEN-LAST:event_tfIngrediente5ActionPerformed

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/lacasadeallado","root","");
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO recetas VALUES ('"+tfNomReceta.getText()+"','"+tfIngrediente1.getText()+"','"+tfCantidad1.getText()+"','"+tfIngrediente2.getText()+"','"+tfCantidad2.getText()+"','"+tfIngrediente3.getText()+"','"+tfCantidad3.getText()+"','"+tfIngrediente4.getText()+"','"+tfCantidad4.getText()+"','"+tfIngrediente5.getText()+"','"+tfCantidad5.getText()+"','"+tfIngrediente6.getText()+"','"+tfCantidad6.getText()+"','"+tfIngrediente7.getText()+"','"+tfCantidad7.getText()+"','"+tfIngrediente8.getText()+"','"+tfCantidad8.getText()+"')");
        } catch (SQLException ex) {
            Logger.getLogger(Registrar.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showConfirmDialog(null, "No se puede conectar a la base de datos");
        }
        JOptionPane.showConfirmDialog(null, "La receta se ha registrado");
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void tfIngrediente1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente1ActionPerformed
        tfIngrediente1.setText("");
    }//GEN-LAST:event_tfIngrediente1ActionPerformed

    private void tfIngrediente3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente3ActionPerformed
        tfIngrediente3.setText("");
    }//GEN-LAST:event_tfIngrediente3ActionPerformed

    private void tfIngrediente4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente4ActionPerformed
        tfIngrediente4.setText("");
    }//GEN-LAST:event_tfIngrediente4ActionPerformed

    private void tfIngrediente6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente6ActionPerformed
        tfIngrediente6.setText("");
    }//GEN-LAST:event_tfIngrediente6ActionPerformed

    private void tfIngrediente7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente7ActionPerformed
        tfIngrediente7.setText("");
    }//GEN-LAST:event_tfIngrediente7ActionPerformed

    private void tfIngrediente8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIngrediente8ActionPerformed
        tfIngrediente8.setText("");
    }//GEN-LAST:event_tfIngrediente8ActionPerformed

    private void tfCantidad5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad5ActionPerformed
        tfCantidad5.setText("");
    }//GEN-LAST:event_tfCantidad5ActionPerformed

    private void tfCantidad1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad1ActionPerformed
        tfCantidad1.setText("");
    }//GEN-LAST:event_tfCantidad1ActionPerformed

    private void tfCantidad2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad2ActionPerformed
        tfCantidad2.setText("");
    }//GEN-LAST:event_tfCantidad2ActionPerformed

    private void tfCantidad3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad3ActionPerformed
        tfCantidad3.setText("");
    }//GEN-LAST:event_tfCantidad3ActionPerformed

    private void tfCantidad4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad4ActionPerformed
        tfCantidad4.setText("");
    }//GEN-LAST:event_tfCantidad4ActionPerformed

    private void tfCantidad6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad6ActionPerformed
        tfCantidad6.setText("");
    }//GEN-LAST:event_tfCantidad6ActionPerformed

    private void tfCantidad7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad7ActionPerformed
        tfCantidad7.setText("");
    }//GEN-LAST:event_tfCantidad7ActionPerformed

    private void tfCantidad8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCantidad8ActionPerformed
        tfCantidad8.setText("");
    }//GEN-LAST:event_tfCantidad8ActionPerformed

    private void tfNomRecetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNomRecetaActionPerformed
        tfNomReceta.setText("");
    }//GEN-LAST:event_tfNomRecetaActionPerformed

    private void btnBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarActionPerformed
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost/lacasadeallado","root","");
            Statement stmt = con.createStatement();
            stmt.executeUpdate("DELETE FROM recetas WHERE Nombre_Receta LIKE ('"+tfNomReceta.getText()+"')");
        } catch (SQLException ex) {
            Logger.getLogger(Registrar.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "No se puede conectar a la base de datos");
        }
        JOptionPane.showMessageDialog(null, "La receta se ha borrado");
    }//GEN-LAST:event_btnBorrarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBorrar;
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JLabel jlRegistroReceta;
    private javax.swing.JTextField tfCantidad1;
    private javax.swing.JTextField tfCantidad2;
    private javax.swing.JTextField tfCantidad3;
    private javax.swing.JTextField tfCantidad4;
    private javax.swing.JTextField tfCantidad5;
    private javax.swing.JTextField tfCantidad6;
    private javax.swing.JTextField tfCantidad7;
    private javax.swing.JTextField tfCantidad8;
    private javax.swing.JTextField tfIngrediente1;
    private javax.swing.JTextField tfIngrediente2;
    private javax.swing.JTextField tfIngrediente3;
    private javax.swing.JTextField tfIngrediente4;
    private javax.swing.JTextField tfIngrediente5;
    private javax.swing.JTextField tfIngrediente6;
    private javax.swing.JTextField tfIngrediente7;
    private javax.swing.JTextField tfIngrediente8;
    private javax.swing.JTextField tfNomReceta;
    // End of variables declaration//GEN-END:variables
}
