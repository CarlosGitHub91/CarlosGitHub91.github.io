import java.util.Scanner;

public class GestorUcrania{
    static Contacto contactos[]= new Contacto[100];
    static Scanner scanner = new Scanner(System.in);

    public static void main(String args[]){
        int opcionSeleccionada = 0;
        do{
            opcionSeleccionada = MostrarMenu();

            switch(opcionSeleccionada){

                case 1: VerContactos();
                break;
                case 2: AgregarContacto();
                break;
                case 3: EliminarContacto();
                break;
                case 4: BuscarNombre();
                break;
                case 5: BusquedaGlobal();
                break;
            }

        }while(opcionSeleccionada!=8);

    }
    public static int MostrarMenu(){
        System.out.println("***MENU PRINCIPAL***");
        System.out.println("1.Ver Contactos");
        System.out.println("2.Agregar Contaco");
        System.out.println("3.Eliminar Contacto");
        System.out.println("4.Buscar por correo");
        System.out.println("5.Buscar por telefono");
        System.out.println("6.Buacar por correo electronico");
        System.out.println("7.Busqueda global");
        System.out.println("8.Salir");
        System.out.println("");

        String opcionSeleccionada = scanner.nextLine();

        return Integer.parseInt(opcionSeleccionada);
    }

    private static void  VerContactos(){
        for(int indice = 0; indice<contactos.length; indice++){
            if(contactos[indice]!=null)
            System.out.println(indice+"."+contactos[indice].MostrarInformacion());
        }
    }
    private static void AgregarContacto(){

        System.out.println("Nombre:");
        String nombre = scanner.nextLine();

        System.out.println("Telefono:");
        String telefono = scanner.nextLine();

        System.out.println("Correo electronico:");
        String correo = scanner.nextLine();

        Contacto nuevoContacto = new Contacto(nombre,correo,telefono);

        for(int indice = 0; indice<contactos.length;indice ++){
            if(contactos[indice]==null){
                contactos[indice]=nuevoContacto;
                break;
            }
        }
    }
    private static void EliminarContacto(){
        VerContactos();
        //Preguntar que contacto quiere eliminar
        System.out.println("Que contacto deseas eliminar");
        int indiceAEliminar = Integer.parseInt(scanner.nextLine());

        //borramos del sistema
        contactos[indiceAEliminar]=null;
    }
    private static void BuscarNombre(){

        //que contacto buscar
        System.out.println("Que nombre busco?");
        String nombreABuscar = scanner.nextLine();

        //recorro el array y muestro solo el contacto que contega el nombre
        for(int indice=0;indice<contactos.length;indice++){
            if(contactos[indice]!=null && contactos[indice].nombre.contains(nombreABuscar)){
                System.out.println(indice+"."+contactos[indice].MostrarInformacion());
            }
        }
    }
    private static void BusquedaGlobal(){
         //que contacto buscar
         System.out.println("Que busco?");
         String aBuscar = scanner.nextLine();
 
         //recorro el array y muestro solo el contacto que contega el nombre
         for(int indice=0;indice<contactos.length;indice++){
             if(contactos[indice]!=null && contactos[indice].nombre.contains(aBuscar)||
             contactos[indice].correo.contains(aBuscar)||
             contactos[indice].telefono.contains(aBuscar)
             ){
                 System.out.println(indice+"."+contactos[indice].MostrarInformacion());
             }
         }
    }
}
