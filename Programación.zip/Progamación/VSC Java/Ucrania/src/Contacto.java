public class Contacto{
    public String nombre;
    public String correo;
    public String telefono;

    public Contacto(String nombre, String correo, String telefono){
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
    }
    public String MostrarInformacion(){
        return nombre+";"+correo+";"+telefono;
    }
}