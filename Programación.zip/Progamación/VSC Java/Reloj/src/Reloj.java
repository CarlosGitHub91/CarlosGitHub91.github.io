import java.util.Scanner;
import java.lang.Math;

public class Reloj {
    public static void main(String[] args) throws Exception {

        int hora, minutos,segundos;
        Double hor,min,seg;

        System.out.println("Creando reloj...");
        Scanner scan = new Scanner(System.in);
        System.out.println("Introduce hora: ");
        hora=scan.nextInt();
        System.out.println("Introduce minutos: ");
        minutos = scan.nextInt();
        System.out.println("Introduce segundos: ");
        segundos = scan.nextInt();

        Double seg1 = (double)segundos/60;
        Double seg2 = seg1 - seg1.intValue();
        seg = seg2*60;

        Double min1 = ((double)minutos + seg1.intValue())/60;
        Double min2 = min1 - min1.intValue();
        min = min2*60;

        hor = (double)hora + min1.intValue();

        System.out.println(Math.round(hor)+"h "+Math.round(min)+"m "+Math.round(seg)+"s");
        scan.close();
    }
}
