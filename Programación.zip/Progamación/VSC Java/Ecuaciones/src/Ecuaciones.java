import java.util.Scanner;

public class Ecuaciones {
    public static void main(String[] args) throws Exception {
        Double a,b,c,x1,x2;
        Scanner scan = new Scanner(System.in);
        System.out.println("Creando ecuación de segundo grado...");
        System.out.println("Introduce valor del exponente a(x^2)");
        a = scan.nextDouble();
        System.out.println("Introduce valor del exponente b(x)");
        b = scan.nextDouble();
        System.out.println("Introduce valor del exponente c(x^2)");
        c = scan.nextDouble();
        scan.close();
        x1=(-b+Math.sqrt(Math.pow(b,2)-(4*a*c)))/(2*a);
        x2=(-b-Math.sqrt(Math.pow(b,2)-(4*a*c)))/(2*a);
        System.out.println("x1="+x1+"\nx2="+x2);
    }
}
