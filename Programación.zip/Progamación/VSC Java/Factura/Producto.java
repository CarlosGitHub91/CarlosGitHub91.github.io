package Ejercicio5;

public class Producto {
    
    private String codigo;
    private String descripcion;
    private float precio;

    public Producto(String codigo, String descripcion, float precio){

        this.codigo=codigo;
        this.descripcion=descripcion;
        this.precio=precio;

    }

    public void setCodigo(String codigo){
        this.codigo=codigo;
    }

    public String getCodigo() { 
        return codigo;
    }

    public void setDescripcion(String descripcion){
        this.descripcion=descripcion;
    }

    public String getDescripcion() { 
        return descripcion;
    }

    public void setPrecio(float precio){
        this.precio=precio;
    }

    public float getPrecio() { 
        return precio;
    }


}
