package Ejercicio5;

public class FacturaTest {
    public static void main (String[] args){

        Cliente clientePrueba = new Cliente("12345678A", "PEPITO", "PALOTES", "Avenida del caramelo sn");
        Factura factura = new Factura(clientePrueba);

        Producto producto1= new Producto("Pastas1", "Macarrones Gallo 500gr.", 1.25f);
        Producto producto2= new Producto("Azucar54", "Azucar Moreno y ole 200gr.", 1.00f);
        Producto producto3= new Producto("Bolleria63", "Mierda de la buena", 1.40f);
        Producto producto4= new Producto("Legumbres6", "Garbanzos La Murcianica tarro 500gr.", 1.25f);

        factura.anyadirProducto(producto1, 1);
        factura.anyadirProducto(producto2, 2);
        factura.anyadirProducto(producto3, 3);
        factura.anyadirProducto(producto4, 4);

        factura.generarTicket();

    }


}
