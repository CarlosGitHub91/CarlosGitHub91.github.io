package Ejercicio5;

public class Factura {
    
    private final float IVA=0.21f; 

    private int cantidades[]=new int[100];
    private Producto productos[]=new Producto[100];
    private Cliente cliente=null;

    public Factura(Cliente cliente){
        this.cliente=cliente;
    }

    public void anyadirProducto(Producto producto, int cantidad){

        for(int indice=0;indice<cantidades.length;indice++){
            if(cantidades[indice]==0){
                cantidades[indice]=cantidad;
                productos[indice]=producto;
                return;
            }
        }

    }

    public float calcularTotal(){

        float suma=0;

        for(int i=0; i< cantidades.length;i++){
            if(cantidades[i]==0){
                continue;
            }
            suma+= cantidades[i] * productos[i].getPrecio();
        }
        suma *=  IVA;
        return suma;

    }

    public void generarTicket(){

        System.out.println("SUPERMERCADO CAMPUS CAMARA FP");
        System.out.println("*****************************");
        System.out.println("");
        System.out.println("Datos del cliente");
        System.out.println("DNI:"+cliente.getDNI());
        System.out.println("Nombre:"+cliente.getNombre());
        System.out.println("Apellidos:"+cliente.getApellidos());
        System.out.println("Direccion:"+cliente.getDireccion());
        System.out.println("");
        System.out.println("*****************************");
        System.out.println("");
        System.out.println("ARTICULOS");
        System.out.println("");

        //Vamos a mostrar los articulos
        // 5 x Pan de molde - 1.50€ - 7.50€
        for(int i = 0 ; i < cantidades.length;i++){

            if(cantidades[i]==0){
                continue;
            }
            System.out.println(cantidades[i]+" x "+productos[i].getDescripcion()+" - "
            +productos[i].getPrecio()+"\u20AC - "+productos[i].getPrecio()*cantidades[i]
            +"\u20AC");
        }

        System.out.println("");
        System.out.println("*****************************");
        System.out.println("");
        System.out.println("IVA: "+IVA*100+"%");
        System.out.println("TOTAL: "+calcularTotal()+"\u20AC");
        System.out.println("");
        System.out.println("GRACIAS POR SU COMPRA. ¡VUELVA PRONTO! (y con pasta)");





    }


}
