package Ejercicio5;

public class Cliente{

    private String DNI;
    private String nombre;
    private String apellidos;
    private String direccion;
    
    public Cliente(String DNI, String nombre, String apellidos, String direccion){

        this.DNI=DNI;
        this.nombre=nombre;     
        this.apellidos=apellidos;
        this.direccion=direccion;

    }

    public void setDNI(String DNI){
        this.DNI=DNI;
    }

    public String getDNI(){
        return DNI;
    }

    public void setNombre(String nombre){
        this.nombre=nombre;
    }

    public String getNombre(){
        return nombre;
    }

    public void setApellidos(String apellidos){
        this.apellidos=apellidos;
    }

    public String getApellidos(){
        return apellidos;
    }

    public void setDireccion(String direccion){
        this.direccion=direccion;
    }

    public String getDireccion(){
        return direccion;
    }
}