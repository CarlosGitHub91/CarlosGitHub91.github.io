
import java.io.*;
import java.util.*;

public class GestorPuntuaciones {
    private Formatter arch;
    String fichero = "Puntuación.txt";
    private int[] puntuacionesGanadoras = new int[10];
    private String[] nombresGanadores = new String[10];

    // Crea Archivo de Puntuaciones.txt
    public void crearPuntuacion(int puntuacion, String nombre) {
        try {
            arch = new Formatter("Puntuacion.txt");
            arch.format("%s\n", nombre);
            arch.format("%s\n", puntuacion);
            for (int index = 2; index < 11; index++) {
                arch.format("%s\n", "___");
                arch.format("%s\n", 0);
            }
            System.out.println("El archivo de puntuaciones se ha creado con éxito");
            arch.close();
        } catch (Exception e) {
            System.out.println("El archivo puntuaciones no se ha creado");
        }
    }

    // Actualiza las Puntuaciones obtenidas
    public void actualizarArchivo() {
        try {
            arch = new Formatter("Puntuacion.txt");
            for (int i = 0; i < 10; i++) {
                arch.format("%s\n", nombresGanadores[i]);
                arch.format("%s\n", puntuacionesGanadoras[i]);
            }
            System.out.println("Se han actualizado las puntuaciones");
            arch.close();
        } catch (Exception e) {
            System.out.println("La actualización ha fallado");
        }
    }

    // Cierra Puntuaciones.txt
    public void cierraArchivo() {
        System.out.println("Cerrando archivo");
        arch.close();
    }

    // Cambia los puesto de los jugadores según la puntuación obtenida en el fichero
    // Puntuaciones.txt
    public void Top10(int contador, String nombre) {
        System.out.println("Ganador es: " + nombre);
        try {
            File miObj = new File("Puntuacion.txt");
            Scanner miFileBuffer = new Scanner(miObj);
            String puntuacion = "";

            boolean cambiar = false;
            System.out.println("___________________");
            System.out.println("******Top 10******");
            System.out.println("Posición:\tNombre:\tPuntuación");

            while (miFileBuffer.hasNext() && contador < 12) {
                nombre = miFileBuffer.nextLine();
                puntuacion = miFileBuffer.nextLine();

                try {
                    if (contador >= Integer.parseInt(puntuacion)) {
                        if (cambiar == false) {
                            nombresGanadores[contador - 1] = nombre;
                            puntuacionesGanadoras[contador - 1] = contador;
                            System.out.printf("%s\t%s\t%s\n", contador, nombre, contador);

                            cambiar = true;

                            nombresGanadores[contador] = nombre;
                            puntuacionesGanadoras[contador] = Integer.parseInt(puntuacion);
                            System.out.printf("%s\t%s\t%s\n", contador + 1, nombre, puntuacion);

                        } else {
                            nombresGanadores[contador] = nombre;
                            puntuacionesGanadoras[contador] = Integer.parseInt(puntuacion);
                            System.out.printf("%s\t%s\t%s\n", contador + 1, nombre, puntuacion);
                        }
                    } else {
                        nombresGanadores[contador - 1] = nombre;
                        puntuacionesGanadoras[contador - 1] = Integer.parseInt(puntuacion);
                        System.out.printf("%s\t%s\t%s\n", contador, nombre, puntuacion);
                    }
                    contador += 1;

                } catch (ArrayIndexOutOfBoundsException e) {
                    break;
                }
            }
            miFileBuffer.close();
            actualizarArchivo();
            cierraArchivo();

        } catch (FileNotFoundException e) {
            crearPuntuacion(contador, nombre);
        } catch (Exception e) {
            System.out.println("Error de lectura");
        }

    }
}
