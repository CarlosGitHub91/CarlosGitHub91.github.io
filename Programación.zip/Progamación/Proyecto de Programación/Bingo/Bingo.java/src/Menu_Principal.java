
import java.util.*;

public class Menu_Principal {
    private static ArrayList<Jugador> jugadores = new ArrayList<Jugador>();

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        menu(scan);
        // It's generally not recommended to close System.in,
        // but if this were a file or other resource, it should be closed.
        // scan.close();
    }

    // Menú
    public static void menu(Scanner scan) {
        while (true) {
            System.out.println("**************************");
            System.out.println("******JUGAR AL BINGO******");
            System.out.println("**************************");
            System.out.println("1.Introducir nuevo jugador\n2.Iniciar juego");

            // Use hasNextInt to check for valid input
            if (!scan.hasNextInt()) {
                System.out.println("Entrada inválida. Por favor, introduce un número.");
                scan.next(); // Consume the invalid input
                continue; // Continue the loop
            }

            int opcion = scan.nextInt();
            scan.nextLine(); // Consume the newline character left by nextInt()

            switch (opcion) {
                case 1:
                    crearJugadores(scan);
                    break;
                case 2:
                    if (jugadores.isEmpty()) {
                        System.out.println("No hay jugadores para iniciar el juego.");
                    } else {
                        jugar(scan);
                    }
                    break;
                default:
                    System.out.println("No existe esa opción");
                    // Continue the loop instead of breaking out entirely
                    break;
            }
        }
    }

    // Crea jugadores
    public static void crearJugadores(Scanner scan) {
        System.out.print("Nombre: ");
        String nombre = scan.nextLine(); // Use nextLine() to read the full name

        System.out.print("Cantidad de cartones: ");
        // Use hasNextInt to check for valid input
        while (!scan.hasNextInt()) {
            System.out.println("Entrada inválida. Por favor, introduce un número para la cantidad de cartones.");
            scan.next(); // Consume the invalid input
            System.out.print("Cantidad de cartones: ");
        }
        int cantidad = scan.nextInt();
        scan.nextLine(); // Consume the newline character left by nextInt()

        if (cantidad > 0) {
            jugadores.add(new Jugador(nombre, cantidad));
            System.out.println("Jugador " + nombre + " añadido con " + cantidad + " cartón(es).");
        } else {
            System.out.println("La cantidad de cartones debe ser mayor que cero.");
        }
    }

    // Inicia el juego, con cada tirada se presiona la tecla enter. Cuando hay Bingo
    // se guardan los datos en un fichero .txt
    public static void jugar(Scanner scan) {
        String nombreGanador = "";
        int puntuacion = 0;

        System.out.println("_____________________");
        System.out.println("Iniciando el Juego...");
        System.out.println("_____________________");

        // Ensure Bingo and GestorPuntuaciones classes exist and are correctly implemented
        Bingo partida = new Bingo(jugadores);
        for (Jugador jugador : jugadores) {
            jugador.mostrarCartones();
        }

        System.out.println("\nPresiona Enter para cada tirada...");

        while (true) {
            // Wait for user to press Enter
            scan.nextLine();

            nombreGanador = partida.tirada(nombreGanador);
            puntuacion += 1;

            // Check if a winner was returned
            if (!nombreGanador.isEmpty()) {
                break; // Exit the loop if a winner is found
            }
        }

        // Assuming lower score is better, hence 90 - puntuacion
        puntuacion = 90 - puntuacion;
        System.out.println(nombreGanador + " tiene una puntuación de " + puntuacion + " puntos");
        System.out.println("______________________________________");
        System.out.println("");

        // Ensure GestorPuntuaciones class exists and has a Top10 method
        GestorPuntuaciones archivo = new GestorPuntuaciones();
        archivo.Top10(puntuacion, nombreGanador);
    }
}