import java.util.*;

public class Carton {

    ArrayList<Integer> numeros = new ArrayList<Integer>(15);
    ArrayList<Integer> num = new ArrayList<Integer>(15);

    // Se crea la lista de 15 números que componen el cartón con 90 posibles números
    public Carton() {
        for (int i = 0; i < 90; i++) {
            num.add(i);
            Collections.shuffle(num);
        }
        for (int i = 0; i < 15; i++) {
            numeros.add(num.get(i));
        }

    }

    // Crea un número aleatorio
    public int random() {
        int num = ((int) (1 + Math.random() * 90));
        return num;
    }

    // Imprime los números del cartón
    public void print() {
        for (int i = 0; i < 15; i++) {
            System.out.println(numeros.get(i) + " ");
        }
    }

    // Comprueba que los numeros en los cartones no estén repetidos
    public boolean checkNumber(int num) {
        boolean repetido = false;

        for (int i = 0; i < numeros.size(); i++) {
            if (num == numeros.get(i)) {
                repetido = true;
            }
        }
        Collections.shuffle(numeros);
        return repetido;
    }

    // Quita o tacha el número del cartón si ha salido la misma bola del bombo
    public boolean tacharNumero(int num) {
        for (int i = 0; i < numeros.size(); i++) {
            if (numeros.get(i) == num) {
                numeros.remove(i);
                return true;
            }
        }
        return false;
    }

    // Se usará para saber cuando el Cartón está vacío
    public boolean rellenar() {
        if (numeros.size() == 0) {
            return true;
        }
        return false;
    }

    // Devuelve todos los números que quedan por tachar
    public String toString(int num) {

        String print = "";
        for (int i = 0; i < numeros.size(); i++) {
            if (numeros.get(i) != 0) {
                if (i == numeros.size() - 1) {
                    print += numeros.get(i);
                } else {
                    print += numeros.get(i) + " - ";
                }
            }
        }
        return print;
    }
}
