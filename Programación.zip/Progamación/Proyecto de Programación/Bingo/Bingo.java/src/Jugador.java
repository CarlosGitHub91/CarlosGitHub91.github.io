import java.util.*;

public class Jugador {
    String nombre;
    private ArrayList<Carton> cartones;
    GestorPuntuaciones puntuaciones = new GestorPuntuaciones();
    Carton carton = new Carton();

    // Se crea la cantidad de cartones que va a jugar el Jugador
    public Jugador(String nombre, int cantidad) {
        this.nombre = nombre;
        this.cartones = new ArrayList<Carton>(cantidad);

        for (int i = 0; i < cantidad; i++) {
            cartones.add(carton);
        }

    }

    // Devuelve el nombre del jugador
    public String getNombre() {
        return nombre;
    }

    // Tacha los números en todos los cartones del jugador, imprime el cartón y
    // devuelve un booleano
    public boolean tacharNumeros(int numeroObtenido) {
        int nCartones = 0;

        for (Carton carton : cartones) {
            if (carton.tacharNumero(numeroObtenido)) {
                nCartones += 1;
                carton.tacharNumero(numeroObtenido);
                System.out.println(nombre + " tacha el número " + numeroObtenido + " en el cartón " + nCartones
                        + " le falta para Bingo\n" + carton.toString(numeroObtenido));
            }
            if (carton.rellenar()) {
                return true;
            }
        }
        return false;
    }

    // Imprime los cartones
    public void mostrarCartones() {
        System.out.println("Cartones de: " + nombre);

        for (int i = 1; i < cartones.size() + 1; i++) {
            System.out.println(i + ". " + cartones.get(i - 1));
        }
    }
}
