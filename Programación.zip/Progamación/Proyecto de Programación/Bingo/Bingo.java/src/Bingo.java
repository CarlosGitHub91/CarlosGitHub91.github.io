import java.util.*;

public class Bingo {

    private ArrayList<Integer> bolas = new ArrayList<Integer>(90);
    private ArrayList<Jugador> jugadores;

    // El Bingo se compone de 90 bolas
    public Bingo(ArrayList<Jugador> jugadores) {
        this.jugadores = jugadores;

        for (int i = 0; i < 90; i++) {
            bolas.add(i);
        }
    }

    // Se saca una bola y se devuelve el nombre del ganador en caso de que se haya
    // hecho Bingo
    public String tirada(String nombreGanador) {
        boolean resultado;
        Random random = new Random();
        Integer numeroObtenido = bolas.get(random.nextInt(bolas.size()));
        System.out.println("Bola:" + numeroObtenido);

        for (Jugador jugador : jugadores) {
            resultado = jugador.tacharNumeros(numeroObtenido);
            if (resultado == true) {
                nombreGanador = jugador.getNombre();
                System.out.println("__________________________");
                System.out.println(nombreGanador + " ha ganado");
                return nombreGanador;
            }
        }
        bolas.remove(numeroObtenido);
        return "";
    }
}
