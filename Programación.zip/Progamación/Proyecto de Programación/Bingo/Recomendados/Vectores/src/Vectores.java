public class Vectores {
    import java.util.Scanner:

    public Vectores() {
        int vector[] = { 5, 3, 8, 7, 9, 25, 32, 41 };
        int max = vector[0];
        int min = vector[0];
        System.out.println("El vector tiene los siguientes numeros");
        for (int i = 0; i < vector.length; i++) {
            if (vector[i] < min) {
                max = vector[i];
            }
            if (vector[i] > max) {
                min = vector[i];
            }
            System.out.println(vector[i]);
        }

        System.out.println("El vector maximo es: " + max);
    }
}
