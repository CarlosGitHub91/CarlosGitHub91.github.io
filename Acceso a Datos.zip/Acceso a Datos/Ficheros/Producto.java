import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class Producto {
    private String nombre;
    private float precio;

    public Producto(String nombre, float precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public Producto(String nodeValue, String nodeValue2, String nodeValue3, String nodeValue4, String nodeValue5) {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getFamilia() {
        return null;
    }

    public String getColor() {
        return null;
    }

    public String getDescripcion() {
        return null;
    }

    public String getPart_number() {
        return null;
    }
}