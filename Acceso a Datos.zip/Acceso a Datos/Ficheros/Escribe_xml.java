import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Text;

public class Escribe_xml {

    static Element nodoProducto = null;
    static Element nodoDatos = null;
    static Text texto = null;

    public static void main(String[] args) {
        DocumentBuilderFactory factoria = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;
        try {
            builder = factoria.newDocumentBuilder();
            DOMImplementation implementation = builder.getDOMImplementation();
            Document document = implementation.createDocument(null, "xml", null);
            Element raiz = document.createElement("productos");
            List<Producto> listaProductos = new ArrayList<Producto>();
            for (Producto producto : listaProductos) {
                nodoProducto = document.createElement("producto");
                raiz.appendChild(nodoProducto);

                nodoDatos = document.createElement("nombre");
                nodoProducto.appendChild(nodoDatos);
                texto = document.createTextNode(producto.getNombre());
                nodoDatos.appendChild(texto);
                nodoDatos = document.createElement("precio");
                nodoProducto.appendChild(nodoDatos);
                texto = document.createTextNode(String.valueOf(producto.getPrecio()));
                nodoDatos.appendChild(texto);
            }
        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}
