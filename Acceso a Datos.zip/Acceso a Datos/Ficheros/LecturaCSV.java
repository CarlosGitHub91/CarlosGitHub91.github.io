import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class LecturaCSV {
    public static final String SEPARATOR=";";
   public static final String QUOTE="\"";

   public static void main(String[] args) throws IOException {

      BufferedReader br = null;
      
      try {
         
         br =new BufferedReader(new FileReader("C:/Users/User/Desktop/Acceso a Datos Ejercicios/GW2.csv"));
         String line = br.readLine();
         while (null!=line) {
            String [] fields = line.split(SEPARATOR);
            System.out.println(Arrays.toString(fields));
            
            fields = removeTrailingQuotes(fields);
            System.out.println(Arrays.toString(fields));
            
            line = br.readLine();
         }
         
      } catch (Exception e) {
        
      } finally {
         if (null!=br) {
            br.close();
         }
      }
    }
    private static String[] removeTrailingQuotes(String[] fields) {
        return null;
        /*String result[] = new String[fields.length];
    
          for (int i=0;i<result.length;i++){
             result[i] = fields[i].replaceAll("^"+QUOTE, "").replaceAll(QUOTE+"$", "");
          }
          return result;*/
    }
}



