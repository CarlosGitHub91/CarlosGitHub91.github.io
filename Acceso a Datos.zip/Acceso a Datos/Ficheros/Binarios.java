
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class Binarios {

   public static void main(String[] args) {
      copia ("/C:/Users/User/Desktop/Acceso a Datos Ejercicios/ficheroOrigen.bin", "/C:/Users/User/Desktop/Acceso a Datos Ejercicios/ficheroDestino.bin");
   }

   public static void copia (String ficheroOriginal, String ficheroCopia)
   {
      // Se declaran fuera del try porque los necesitamos dentro del finally para poder cerrarlos.
      BufferedInputStream bufferedInput = null;
      BufferedOutputStream bufferedOutput = null;

      try {
         // Se abre el fichero original para lectura
         FileInputStream fileInput = new FileInputStream(ficheroOriginal);
         bufferedInput = new BufferedInputStream(fileInput);
			
         // Se abre el fichero donde se hará la copia
         FileOutputStream fileOutput = new FileOutputStream (ficheroCopia);
         bufferedOutput = new BufferedOutputStream(fileOutput);
			
         // Bucle para leer de un fichero y escribir en el otro.
         byte [] array = new byte[1000];
         int leidos = bufferedInput.read(array);
         while (leidos > 0)
         {
            bufferedOutput.write(array,0,leidos);
            leidos=bufferedInput.read(array);
         }

      } catch (Exception e) {
         e.printStackTrace();
      } finally {
         try {
            if (null != bufferedInput) {
               bufferedInput.close();
            }
         } catch (Exception e2) {
            e2.printStackTrace();
         }
         try {
            if (null != bufferedOutput) {
               bufferedOutput.close();
            }
         } catch (Exception e3) {
            e3.printStackTrace();
         }
      }
   }
}