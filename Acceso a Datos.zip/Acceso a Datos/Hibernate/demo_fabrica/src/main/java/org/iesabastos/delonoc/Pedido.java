package org.iesabastos.delonoc;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "pedidos")
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int num;
    private Date fecha;
    private int unidades;
    private boolean urgente;
    private boolean servido;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "codfabrica")
    private Fabrica fabrica;

    public Pedido() {
    }

    public int getNum() {
        return this.num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Date getFecha() {
        return this.fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getUnidades() {
        return this.unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    public boolean isUrgente() {
        return this.urgente;
    }

    public boolean getUrgente() {
        return this.urgente;
    }

    public void setUrgente(boolean urgente) {
        this.urgente = urgente;
    }

    public boolean isServido() {
        return this.servido;
    }

    public boolean getServido() {
        return this.servido;
    }

    public void setServido(boolean servido) {
        this.servido = servido;
    }

    public Fabrica getFabrica() {
        return this.fabrica;
    }

    public void setFabrica(Fabrica fabrica) {
        this.fabrica = fabrica;
    }

}