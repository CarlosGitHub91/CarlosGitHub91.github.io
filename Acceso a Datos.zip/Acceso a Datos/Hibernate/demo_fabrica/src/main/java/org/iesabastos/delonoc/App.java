package org.iesabastos.delonoc;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");

        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            int cod = 1;
            HibernateUtil.getCurrentSession().get(Fabrica.class, cod);

            Query query = (Query) HibernateUtil.getCurrentSession().createQuery("SELECT * from Fabrica");
            ArrayList<Fabrica> fabrica = (ArrayList<Fabrica>) query.list();
            System.out.println(fabrica);
            /* sesion.delete(detallesDelPedido); */

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            // TODO: handle exception
        }
    }
}
