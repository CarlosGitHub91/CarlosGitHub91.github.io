package org.iesabastos.delonoc;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class Persona implements Serializable {
    private int num;
    private Date fecha;
    private int unidades;
    private boolean urgente;
    private boolean servido;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "codarticulo")
    private Articulo articulo;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "codfabrica")
    private Fabrica fabrica;

    public Persona() {
    }

    public int getNum() {
        return this.num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Date getFecha() {
        return this.fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getUnidades() {
        return this.unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    public boolean isUrgente() {
        return this.urgente;
    }

    public boolean getUrgente() {
        return this.urgente;
    }

    public void setUrgente(boolean urgente) {
        this.urgente = urgente;
    }

    public boolean isServido() {
        return this.servido;
    }

    public boolean getServido() {
        return this.servido;
    }

    public void setServido(boolean servido) {
        this.servido = servido;
    }

    public Articulo getArticulo() {
        return this.articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Fabrica getFabrica() {
        return this.fabrica;
    }

    public void setFabrica(Fabrica fabrica) {
        this.fabrica = fabrica;
    }

}
