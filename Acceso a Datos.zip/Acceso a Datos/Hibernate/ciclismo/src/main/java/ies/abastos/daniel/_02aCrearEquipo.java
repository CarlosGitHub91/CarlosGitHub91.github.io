package ies.abastos.daniel;

import org.hibernate.*;

public class _02aCrearEquipo {
    public static void funcion(Session sesion) {

        String nEquipo = Input.getString("Introduce el nombre del equipo");
        String director = Input.getString("Introduce el nombre del director");

        Query query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", nEquipo);
        Equipo e = (Equipo) query.uniqueResult();

        if (e != null) {
            System.out.println("El equipo ya existe");
        } else {
            Equipo n = new Equipo();
            n.setNomeq(nEquipo);
            n.setDirector(director);
            sesion.save(n);
        }
    }
}
