package ies.abastos.daniel;

import org.hibernate.*;

public class _01a02CiclistasDeEquipo {
    @SuppressWarnings("deprecation")
    public static void funcion(Session sesion) {
        @SuppressWarnings({ "deprecation", "rawtypes" })
        Query query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", Input.getString("Introduce el nombre del equipo"));
        Equipo e = (Equipo) query.uniqueResult();

        for (Ciclista c: e.getEquipos()) {
            System.out.println(c.getNombre());
        }
    }
}
