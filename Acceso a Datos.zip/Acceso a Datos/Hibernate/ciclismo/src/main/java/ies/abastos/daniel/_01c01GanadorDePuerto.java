package ies.abastos.daniel;

import org.hibernate.*;

public class _01c01GanadorDePuerto {

    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("from Puerto t WHERE t.nompuerto =:valor");
        query.setParameter("valor", Input.getString("Introduce el nombre del puerto"));
        Puerto e = (Puerto) query.uniqueResult();
        System.out.print("Ganó: " + e.getCiclista().getNombre());
    }
}
