package ies.abastos.daniel;

import org.hibernate.Session;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

            _01a01DirectorDelCiclista.funcion(sesion);
            //_01a02CiclistasDeEquipo.funcion(sesion);
            // _01b01GanadorDeEtapa.funcion(sesion);
            // _01b02EtapasGanadasPorCiclista.funcion(sesion);
            // _01b03EtapasGanadasPorEquipo.funcion(sesion);
            //_01c01GanadorDePuerto.funcion(sesion);
            //_01c02PuertosGanadosPorCiclista.funcion(sesion);
            // _02aCrearEquipo.funcion(sesion);
            //_02bModificarEquipo.funcion(sesion);
            // _02cCambiarDeEquipo.funcion(sesion);
            // _02dCrearCiclista.funcion(sesion);
            // _03EliminarEquipo.funcion(sesion);
            // _04EliminarEquipoYCambiarCiclistas.funcion(sesion);
            // _05HQLBasicas.funcion(sesion);
            // _06HQLVariasTablas.funcion(sesion);

            sesion.getTransaction().commit();
            sesion.close();
            // System.out.println( "Todo OK!" );
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("*****************Error*****************");
        }
    }
}
