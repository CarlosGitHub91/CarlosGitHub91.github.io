package ies.abastos.daniel;

import org.hibernate.*;

public class _01b02EtapasGanadasPorCiclista {

    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("from Ciclista t WHERE t.dorsal =:valor");
        query.setParameter("valor", Input.getShort("Introduce el numero del dorsal"));
        Ciclista c = (Ciclista) query.uniqueResult();
        for (Etapa e : c.getEtapa()) {
            System.out.println("Sale de " + e.getSalida() + " y llega a " + e.getLlegada());
        }
    }
}
