package ies.abastos.daniel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.hibernate.*;

public class _05HQLBasicas {

    public static void funcion(Session sesion) throws ParseException {

        Date start = new SimpleDateFormat("yyyy-MM-dd").parse("1979-1-1");
        Date end = new SimpleDateFormat("yyyy-MM-dd").parse("1980-12-31");

        Query query = sesion.createQuery("from Ciclista c where c.nacimiento between :start and :end ");
        query.setParameter("start", start).setParameter("end", end);
        List<Ciclista> a = (ArrayList<Ciclista>) query.list();

        System.out.println("Ciclistas entre 1979-1-1 y 1980-12-31:");
        for (Ciclista cic : a) {
            System.out.println(cic.getNombre());
        }

        query = sesion.createQuery("select count(*) from Ciclista");
        Long b = (Long) query.uniqueResult();
        System.out.println("\nHay " + b + " ciclistas");

        query = sesion.createQuery("select count(*) from Ciclista c where c.equipo = 'Banesto'");
        Long c = (Long) query.uniqueResult();
        System.out.println("\nHay " + c + " ciclistas en Banesto");

    }

}
