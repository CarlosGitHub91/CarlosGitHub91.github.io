package ies.abastos.daniel;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "puerto")
public class Puerto implements Serializable{
    @Id
    @Column
    private String nompuerto;
    @Column
    private short altura;
    @Column
    private String categoria;
    @Column
    private double pendiente;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "netapa")
    private Etapa etapa;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "dorsal")
    private Ciclista ciclista;

    public Puerto() {
    }

    public String getNompuerto() {
        return this.nompuerto;
    }

    public void setNompuerto(String nompuerto) {
        this.nompuerto = nompuerto;
    }

    public short getAltura() {
        return this.altura;
    }

    public void setAltura(short altura) {
        this.altura = altura;
    }

    public String getCategoria() {
        return this.categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPendiente() {
        return this.pendiente;
    }

    public void setPendiente(double pendiente) {
        this.pendiente = pendiente;
    }

    public Etapa getEtapa() {
        return this.etapa;
    }

    public void setEtapa(Etapa etapa) {
        this.etapa = etapa;
    }

    public Ciclista getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(Ciclista ciclista) {
        this.ciclista = ciclista;
    }

}
