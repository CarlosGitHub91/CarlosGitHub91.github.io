package ies.abastos.daniel;

import org.hibernate.*;

public class _01b01GanadorDeEtapa {
    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("from Etapa t WHERE t.netapa =:valor");
        query.setParameter("valor", Input.getShort("Introduce el numero de etapa"));
        Etapa e = (Etapa) query.uniqueResult();
        System.out.println("Esta etapa la ganó " + e.getCiclista().getNombre());
    }
}
