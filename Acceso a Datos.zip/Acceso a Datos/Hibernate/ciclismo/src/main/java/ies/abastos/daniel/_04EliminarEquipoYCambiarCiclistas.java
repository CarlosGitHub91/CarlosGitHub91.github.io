package ies.abastos.daniel;

import org.hibernate.*;

public class _04EliminarEquipoYCambiarCiclistas {
    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", Input.getString("Introduce el nombre del equipo a borrar"));
        Equipo b = (Equipo) query.uniqueResult();

        query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", Input.getString("Introduce el nombre del equipo a traspasar"));
        Equipo e = (Equipo) query.uniqueResult();

        if (e == null) {
            System.out.println("El equipo a traspasar no existe");
        } else if (b == null) {
            System.out.println("El equipo a borrar no existe");
        } else {
            for (Ciclista c : b.getEquipos()) {
                c.setEquipo(e);
                sesion.save(c);
                System.out.println("moviendo");
            }
            sesion.delete(b);
        }
    }
}
