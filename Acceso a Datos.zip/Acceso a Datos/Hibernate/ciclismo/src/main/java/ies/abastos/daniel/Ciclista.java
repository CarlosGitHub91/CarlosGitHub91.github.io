package ies.abastos.daniel;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "ciclista")
public class Ciclista implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private short dorsal;
    @Column
    private String nombre;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "nomeq")
    private Equipo equipo;
    @Column
    private Date nacimiento;

    @OneToMany(mappedBy = "ciclista", cascade = CascadeType.DETACH)
    private List<Etapa> etapa = new ArrayList<Etapa>();

    public Ciclista() {
    }

    public short getDorsal() {
        return this.dorsal;
    }

    public void setDorsal(short dorsal) {
        this.dorsal = dorsal;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Equipo getEquipo() {
        return this.equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public Date getNacimiento() {
        return this.nacimiento;
    }

    public void setNacimiento(Date nacimiento) {
        this.nacimiento = nacimiento;
    }

    public List<Etapa> getEtapa() {
        return this.etapa;
    }

    public void setEtapa(List<Etapa> etapa) {
        this.etapa = etapa;
    }
}
