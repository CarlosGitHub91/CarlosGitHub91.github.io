package ies.abastos.daniel;

import org.hibernate.*;

public class _02cCambiarDeEquipo {

    public static void funcion(Session sesion) {
        short dorsal = Input.getShort("Introduce el dorsal del ciclista");
        String nombre = Input.getString("Introduce el nombre del ciclista");
        String nEquipo = Input.getString("Introduce el nombre del equipo");
        boolean cOk = false;

        Query query = sesion.createQuery("from Ciclista t WHERE t.dorsal =:valor");
        query.setParameter("valor", dorsal);
        Ciclista c = (Ciclista) query.uniqueResult();

        query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", nEquipo);
        Equipo e = (Equipo) query.uniqueResult();

        if (c == null) {
            System.out.println("El dorsal no existe");
        } else if (!c.getNombre().equalsIgnoreCase(nombre)) {
            System.out.println("Nombre incorrecto");
        } else if (c.getEquipo().getNomeq().equals(nEquipo)) {
            System.out.println("El ciclista ya pertenece a ese equipo");
        } else {
            cOk = true;
        }

        if (e == null) {
            System.out.println("El equipo no existe");
        } else if (cOk) {
            c.setEquipo(e);
            sesion.save(c);
        }
    }
}
