package ies.abastos.daniel;

import org.hibernate.*;

public class _01a01DirectorDelCiclista {
    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("from Ciclista t WHERE t.dorsal =:valor");
        query.setParameter("valor", Input.getString("Introduce el nombre del ciclista"));
        Ciclista e = (Ciclista) query.uniqueResult();
        System.out.println("El director es: "+e.getEquipo().getDirector());
    }
}
