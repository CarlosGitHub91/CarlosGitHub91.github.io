package ies.abastos.daniel;

import org.hibernate.Session;
import org.hibernate.query.Query;

public class _01c02PuertosGanadosPorCiclista {

    public static void funcion(Session sesion) {
        short dorsal = Input.getShort("Introduce el dorsal del ciclista");

        // Usamos generics y consulta tipada
        Query<Ciclista> query = sesion.createQuery("from Ciclista c where c.dorsal = :dorsal", Ciclista.class);
        query.setParameter("dorsal", dorsal);

        Ciclista ciclista = query.uniqueResult();

        if (ciclista == null) {
            System.out.println("No se encontró un ciclista con ese dorsal.");
            return;
        }

        // Mostramos los puertos asociados
        // Añadir verificación si la colección de puertos no es nula
        if (ciclista.getPuerto() != null) {
            for (Puerto puerto : ciclista.getPuerto()) {
                System.out.printf("Nombre: %s || Altura: %d || Categoría: %s%n",
                        puerto.getNompuerto(),
                        puerto.getAltura(),
                        puerto.getCategoria());
            }
        } else {
            System.out.println("El ciclista no tiene puertos asociados.");
        }
    }
}
