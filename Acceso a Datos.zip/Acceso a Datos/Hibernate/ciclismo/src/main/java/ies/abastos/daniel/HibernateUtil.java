package ies.abastos.daniel;
// Indicar el nombre del paquete correctamente


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
//import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Clase que facilita el trabajo con Hibernate
 * 
 */
public class HibernateUtil {

  private static SessionFactory sessionFactory;
  private static Session session;

  /**
   * Crea la factoria de sesiones
   */
  public static void buildSessionFactory() {

    Configuration configuration = new Configuration();
    configuration.configure();
    try (ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(
        configuration.getProperties()).getBootstrapServiceRegistry()) {
      sessionFactory = configuration.buildSessionFactory(serviceRegistry);
    } catch (HibernateException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
  }

  /**
   * Abre una nueva sesión
   */
  public static void openSession() {

    session = sessionFactory.openSession();
  }

  /**
   * Devuelve la sesión actual
   * 
   * @return
   */
  public static Session getCurrentSession() {

    if ((session == null) || (!session.isOpen()))
      openSession();

    return session;
  }

  /**
   * Cierra Hibernate
   */
  public static void closeSessionFactory() {

    if (session != null)
      session.close();

    if (sessionFactory != null)
      sessionFactory.close();
  }
}