package ies.abastos.daniel;

import org.hibernate.*;

public class _01b03EtapasGanadasPorEquipo {
    public static void funcion(Session sesion) {

        Query query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", Input.getString("Introduce el nombre del equipo"));
        Equipo e = (Equipo) query.uniqueResult();
        for (Ciclista c : e.getEquipos()) {
            System.out.print(c.getNombre() + " ha ganado: "+c.getEtapa().size()+" etapa(s) \n");
        }
    }
}
