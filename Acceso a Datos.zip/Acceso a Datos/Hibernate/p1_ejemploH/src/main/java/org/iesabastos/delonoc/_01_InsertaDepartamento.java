package org.iesabastos.delonoc;


import org.hibernate.HibernateException;
import org.hibernate.Session;

public class _01_InsertaDepartamento {
    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

            Departamentos departamentos = new Departamentos();
            departamentos.setDept_NO((byte) 13);
            departamentos.setDnombre("Catalán");
            departamentos.setLoc("asd");
            sesion.save(departamentos);
            System.out.println("Fin");

            sesion.getTransaction().commit();
            sesion.close();

        } catch (HibernateException he) {
            he.printStackTrace();
            System.out.println("Excepcion!");
        }

    }
}