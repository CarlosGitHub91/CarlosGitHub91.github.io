package org.iesabastos.delonoc;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.*;

public class _04_ListadoDep {

    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("from Departamentos");
        List<Departamentos> departamentos = (ArrayList<Departamentos>) query.list();
        for (Departamentos d : departamentos) {
            System.out.println(d.getDept_NO() + " " + d.getDnombre());
        }
        sesion.save(10);
    }

}
