package org.iesabastos.delonoc;

import java.util.Properties;

public class ServiceRegistryBuilder {

    public Object applySettings(Properties properties) {
        return null;
    }

}
