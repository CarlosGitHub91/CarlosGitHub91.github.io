package org.iesabastos.delonoc;


import org.hibernate.*;

public class _05_ListadoDep {
    public static void funcion(Session sesion) {
        Departamentos d = (Departamentos) sesion.get(Departamentos.class, (byte) 19);
        System.out.println(d.getDept_NO() + "" + d.getDnombre() + "" + d.getLoc());

        /*
         * Query query =
         * sesion.createQuery("from Departamento d WHERE d.depth_NO = 19");
         * ArrayList<Departamentos> departamentos = (ArrayList<Departamentos>)
         * query.list();
         * for (Departamentos dept : departamentos) {
         * System.out.println(dept.getDept_NO());
         * }
         */
    }
}
