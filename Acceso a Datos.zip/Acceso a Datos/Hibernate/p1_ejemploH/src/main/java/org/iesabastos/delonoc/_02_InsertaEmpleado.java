package org.iesabastos.delonoc;

import java.util.Date;

import org.hibernate.Session;

public class _02_InsertaEmpleado {

    public static void funcion(byte NO, String nombre, String oficio, Date fecha_alta, float salario,
            float comision, Session sesion) {
        Empleados empleados = new Empleados();
        empleados.emp_no((byte) 13);
        empleados.nombre("null");
        empleados.oficio("null");
        empleados.fecha_alta(null);
        empleados.salario(13);
        empleados.comision(13);
        sesion.save(empleados);
    }
}
