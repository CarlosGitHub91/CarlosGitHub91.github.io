package org.iesabastos.delonoc;

import java.util.ArrayList;

import org.hibernate.*;

public class _06_BorraEmpleado {
    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("DELETE FROM Empleado e WHERE e.emp_no = 13;");
        ArrayList<Empleados> empleado = (ArrayList<Empleados>) query.list();
        for (Empleados e : empleado) {
            System.out.println(e.getEmp_no() + "" + e.getNombre() + "" + e.getOficio() + "" + e.getComision() + ""
                    + e.getSalario());
        }
    }
}
