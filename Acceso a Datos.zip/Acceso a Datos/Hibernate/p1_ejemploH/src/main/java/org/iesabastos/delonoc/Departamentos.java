package org.iesabastos.delonoc;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "departamentos")
public class Departamentos implements Serializable{
    @Id
    @Column(name = "dept_no")
    private short dept_NO;
    @Column(name = "dnombre")
    private String dnombre;
    @Column
    private String loc;
    
    @OneToMany(mappedBy = "departamentos", cascade = CascadeType.ALL)
    private List<Empleados> empleados = new ArrayList<Empleados>();


    public Departamentos() {
    }

    public short getDept_NO() {
        return this.dept_NO;
    }

    public void setDept_NO(short dept_NO) {
        this.dept_NO = dept_NO;
    }

    public String getDnombre() {
        return this.dnombre;
    }

    public void setDnombre(String dnombre) {
        this.dnombre = dnombre;
    }

    public String getLoc() {
        return this.loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public List<Empleados> getEmpleados() {
        return this.empleados;
    }

    public void setEmpleados(List<Empleados> empleados) {
        this.empleados = empleados;
    }

    public Departamentos dept_NO(short dept_NO) {
        setDept_NO(dept_NO);
        return this;
    }

    public Departamentos dnombre(String dnombre) {
        setDnombre(dnombre);
        return this;
    }

    public Departamentos loc(String loc) {
        setLoc(loc);
        return this;
    }

    public Departamentos empleados(List<Empleados> empleados) {
        setEmpleados(empleados);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
            " dept_NO='" + getDept_NO() + "'" +
            ", dnombre='" + getDnombre() + "'" +
            ", loc='" + getLoc() + "'" +
            ", empleados='" + getEmpleados() + "'" +
            "}";
    }
}    