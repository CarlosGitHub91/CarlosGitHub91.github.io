package org.iesabastos.delonoc;

import org.hibernate.*;

public class _07_ModificaEmpleado {
    public static void _funcion(String nombre, Session sesion) {
        Empleados e = (Empleados) sesion.get(Empleados.class, nombre);
        e.setNombre(nombre);
        sesion.save(e);
    }

}
