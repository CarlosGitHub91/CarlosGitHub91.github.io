package org.iesabastos.delonoc;

import org.hibernate.HibernateException;
import org.hibernate.Session;

/**
 * Hello world!
 *
 */
public class App {

    public static void main(String[] args) {


        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

             //_01_InsertaDepartamento.funcion(sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (HibernateException he) {
            he.printStackTrace();
            System.out.println("Excepcion!");
        }

    }

}
