package org.iesabastos.delonoc;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.*;

@Entity
@Table(name = "empleados")
public class Empleados implements Serializable{

    @Id
    @Column(name = "emp_no")
    private byte emp_no;
    private String nombre;
    private String oficio;
    @Column(name = "fecha_alta")
    private Date fecha_alta;
    private float salario;
    private float comision;
    private byte dept_NO;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "depth_no")
    private Departamentos departamentos;


    public Empleados() {
    }


    public byte getEmp_no() {
        return this.emp_no;
    }

    public void setEmp_no(byte emp_no) {
        this.emp_no = emp_no;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getOficio() {
        return this.oficio;
    }

    public void setOficio(String oficio) {
        this.oficio = oficio;
    }

    public Date getFecha_alta() {
        return this.fecha_alta;
    }

    public void setFecha_alta(Date fecha_alta) {
        this.fecha_alta = fecha_alta;
    }

    public float getSalario() {
        return this.salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public float getComision() {
        return this.comision;
    }

    public void setComision(float comision) {
        this.comision = comision;
    }

    public byte getDept_NO() {
        return this.dept_NO;
    }

    public void setDept_NO(byte dept_NO) {
        this.dept_NO = dept_NO;
    }

    public Departamentos getDepartamentos() {
        return this.departamentos;
    }

    public void setDepartamentos(Departamentos departamentos) {
        this.departamentos = departamentos;
    }

    public Empleados emp_no(byte emp_no) {
        setEmp_no(emp_no);
        return this;
    }

    public Empleados nombre(String nombre) {
        setNombre(nombre);
        return this;
    }

    public Empleados oficio(String oficio) {
        setOficio(oficio);
        return this;
    }

    public Empleados fecha_alta(Date fecha_alta) {
        setFecha_alta(fecha_alta);
        return this;
    }

    public Empleados salario(float salario) {
        setSalario(salario);
        return this;
    }

    public Empleados comision(float comision) {
        setComision(comision);
        return this;
    }

    public Empleados dept_NO(byte dept_NO) {
        setDept_NO(dept_NO);
        return this;
    }

    public Empleados departamentos(Departamentos departamentos) {
        setDepartamentos(departamentos);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
            " emp_no='" + getEmp_no() + "'" +
            ", nombre='" + getNombre() + "'" +
            ", oficio='" + getOficio() + "'" +
            ", fecha_alta='" + getFecha_alta() + "'" +
            ", salario='" + getSalario() + "'" +
            ", comision='" + getComision() + "'" +
            ", dept_NO='" + getDept_NO() + "'" +
            ", departamentos='" + getDepartamentos() + "'" +
            "}";
    }
}
    