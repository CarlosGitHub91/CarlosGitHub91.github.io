package org.iesabastos.delonoc.Pojos;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "etapa")
public class Etapa {
    @Column
    private short netapa;
    @Column
    private short km;
    @Column
    private String salida;
    @Column
    private String llegada;
    @Column
    private short dorsal;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "ciclista")
    private Ciclista ciclista;
    @OneToMany(mappedBy = "puerto", cascade = CascadeType.ALL)
    private List<Puerto> puerto = new ArrayList<Puerto>();
    @OneToMany(mappedBy = "llevar", cascade = CascadeType.ALL)
    private List<Llevar> llevar = new ArrayList<Llevar>();

    public Etapa() {
    }

    public Etapa(short netapa, short km, String salida, String llegada, short dorsal, Ciclista ciclista,
            List<Puerto> puerto, List<Llevar> llevar) {
        this.netapa = netapa;
        this.km = km;
        this.salida = salida;
        this.llegada = llegada;
        this.dorsal = dorsal;
        this.ciclista = ciclista;
        this.puerto = puerto;
        this.llevar = llevar;
    }

    public short getNetapa() {
        return this.netapa;
    }

    public void setNetapa(short netapa) {
        this.netapa = netapa;
    }

    public short getKm() {
        return this.km;
    }

    public void setKm(short km) {
        this.km = km;
    }

    public String getSalida() {
        return this.salida;
    }

    public void setSalida(String salida) {
        this.salida = salida;
    }

    public String getLlegada() {
        return this.llegada;
    }

    public void setLlegada(String llegada) {
        this.llegada = llegada;
    }

    public short getDorsal() {
        return this.dorsal;
    }

    public void setDorsal(short dorsal) {
        this.dorsal = dorsal;
    }

    public Ciclista getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(Ciclista ciclista) {
        this.ciclista = ciclista;
    }

    public List<Puerto> getPuerto() {
        return this.puerto;
    }

    public void setPuerto(List<Puerto> puerto) {
        this.puerto = puerto;
    }

    public List<Llevar> getLlevar() {
        return this.llevar;
    }

    public void setLlevar(List<Llevar> llevar) {
        this.llevar = llevar;
    }

    public Etapa netapa(short netapa) {
        setNetapa(netapa);
        return this;
    }

    public Etapa km(short km) {
        setKm(km);
        return this;
    }

    public Etapa salida(String salida) {
        setSalida(salida);
        return this;
    }

    public Etapa llegada(String llegada) {
        setLlegada(llegada);
        return this;
    }

    public Etapa dorsal(short dorsal) {
        setDorsal(dorsal);
        return this;
    }

    public Etapa ciclista(Ciclista ciclista) {
        setCiclista(ciclista);
        return this;
    }

    public Etapa puerto(List<Puerto> puerto) {
        setPuerto(puerto);
        return this;
    }

    public Etapa llevar(List<Llevar> llevar) {
        setLlevar(llevar);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
                " netapa='" + getNetapa() + "'" +
                ", km='" + getKm() + "'" +
                ", salida='" + getSalida() + "'" +
                ", llegada='" + getLlegada() + "'" +
                ", dorsal='" + getDorsal() + "'" +
                ", ciclista='" + getCiclista() + "'" +
                ", puerto='" + getPuerto() + "'" +
                ", llevar='" + getLlevar() + "'" +
                "}";
    }

}
