package org.iesabastos.delonoc.Pojos;

import javax.persistence.*;

@Entity
@Table(name = "puerto")
public class Puerto {
    @Column
    private String nompuerto;
    @Column
    private short altura;
    @Column
    private String categoria;
    @Column
    private double pendiente;
    @Column
    private short netapa;
    @Column
    private short dorsal;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "etapa")
    private Etapa etapa;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "ciclista")
    private Ciclista ciclista;

    public Puerto() {
    }

    public Puerto(String nompuerto, short altura, String categoria, double pendiente, short netapa, short dorsal,
            Etapa etapa, Ciclista ciclista) {
        this.nompuerto = nompuerto;
        this.altura = altura;
        this.categoria = categoria;
        this.pendiente = pendiente;
        this.netapa = netapa;
        this.dorsal = dorsal;
        this.etapa = etapa;
        this.ciclista = ciclista;
    }

    public String getNompuerto() {
        return this.nompuerto;
    }

    public void setNompuerto(String nompuerto) {
        this.nompuerto = nompuerto;
    }

    public short getAltura() {
        return this.altura;
    }

    public void setAltura(short altura) {
        this.altura = altura;
    }

    public String getCategoria() {
        return this.categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPendiente() {
        return this.pendiente;
    }

    public void setPendiente(double pendiente) {
        this.pendiente = pendiente;
    }

    public short getNetapa() {
        return this.netapa;
    }

    public void setNetapa(short netapa) {
        this.netapa = netapa;
    }

    public short getDorsal() {
        return this.dorsal;
    }

    public void setDorsal(short dorsal) {
        this.dorsal = dorsal;
    }

    public Etapa getEtapa() {
        return this.etapa;
    }

    public void setEtapa(Etapa etapa) {
        this.etapa = etapa;
    }

    public Ciclista getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(Ciclista ciclista) {
        this.ciclista = ciclista;
    }

    public Puerto nompuerto(String nompuerto) {
        setNompuerto(nompuerto);
        return this;
    }

    public Puerto altura(short altura) {
        setAltura(altura);
        return this;
    }

    public Puerto categoria(String categoria) {
        setCategoria(categoria);
        return this;
    }

    public Puerto pendiente(double pendiente) {
        setPendiente(pendiente);
        return this;
    }

    public Puerto netapa(short netapa) {
        setNetapa(netapa);
        return this;
    }

    public Puerto dorsal(short dorsal) {
        setDorsal(dorsal);
        return this;
    }

    public Puerto etapa(Etapa etapa) {
        setEtapa(etapa);
        return this;
    }

    public Puerto ciclista(Ciclista ciclista) {
        setCiclista(ciclista);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
                " nompuerto='" + getNompuerto() + "'" +
                ", altura='" + getAltura() + "'" +
                ", categoria='" + getCategoria() + "'" +
                ", pendiente='" + getPendiente() + "'" +
                ", netapa='" + getNetapa() + "'" +
                ", dorsal='" + getDorsal() + "'" +
                ", etapa='" + getEtapa() + "'" +
                ", ciclista='" + getCiclista() + "'" +
                "}";
    }

}
