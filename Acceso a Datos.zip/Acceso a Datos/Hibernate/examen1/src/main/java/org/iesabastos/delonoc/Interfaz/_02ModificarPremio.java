package org.iesabastos.delonoc.Interfaz;

import java.util.ArrayList;
import org.hibernate.Query;
import org.hibernate.Session;
import org.iesabastos.delonoc.Pojos.Maillot;
import org.iesabastos.delonoc.Utils.HibernateUtil;

public class _02ModificarPremio {

    static int premio;
    static double cambio;

    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            funcion(sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    }

    public static void funcion(Session sesion) {

        cambio = (double) premio * 166.386;
        Query query = sesion.createQuery("from Maillot");
        ArrayList<Maillot> maillot = (ArrayList<Maillot>) query.list();
        for (Maillot m : maillot) {
            m.setPremio((int) cambio);
            System.out.println(m.getPremio());
        }
        /*
         * Maillot x = (Maillot) sesion.get(Maillot.class, premio);
         * x.setPremio((int)cambio);
         * sesion.save(x);
         */
        sesion.save(maillot);
    }
}
