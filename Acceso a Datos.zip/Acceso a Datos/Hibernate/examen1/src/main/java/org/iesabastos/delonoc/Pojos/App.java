package org.iesabastos.delonoc.Pojos;

import org.hibernate.*;
import org.iesabastos.delonoc.Utils.HibernateUtil;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            // _01b01DirectorDelCiclista.funcion("Pepe", sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    }
}
