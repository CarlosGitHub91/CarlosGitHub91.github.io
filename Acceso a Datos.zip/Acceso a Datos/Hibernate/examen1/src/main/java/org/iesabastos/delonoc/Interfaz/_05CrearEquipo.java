package org.iesabastos.delonoc.Interfaz;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.iesabastos.delonoc.Pojos.Ciclista;
import org.iesabastos.delonoc.Pojos.Equipo;
import org.iesabastos.delonoc.Utils.HibernateUtil;

public class _05CrearEquipo {
    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            funcion(sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    }

    public static void funcion(Session sesion) {

        Equipo equipo = new Equipo();
        equipo.setNomeq("VIP");
        equipo.setDirector("Edvard Grieg");
        sesion.save(equipo);

        Query query = sesion.createQuery("from Ciclista");
        ArrayList<Ciclista> ciclista = (ArrayList<Ciclista>) query.list();
        for (Ciclista c : ciclista) {
            if (c.getLlevar().get(0).getMaillot().getPremio() >= 40000) {
                System.out.println(c.getNombre());
            }
        }
    }
}
