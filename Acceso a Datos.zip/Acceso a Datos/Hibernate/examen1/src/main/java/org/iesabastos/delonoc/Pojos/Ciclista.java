package org.iesabastos.delonoc.Pojos;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "ciclista")
public class Ciclista {
    @Id
    private short dorsal;
    @Column
    private String nombre;
    @Column
    private String nomeq;
    @Column
    private Date fechanac;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "equipo")
    private Equipo equipo;
    @OneToMany(mappedBy = "puerto", cascade = CascadeType.ALL)
    private List<Puerto> puertos = new ArrayList<Puerto>();
    @OneToMany(mappedBy = "llevar", cascade = CascadeType.ALL)
    private List<Llevar> llevar = new ArrayList<Llevar>();
    @OneToMany(mappedBy = "etapa", cascade = CascadeType.ALL)
    private List<Etapa> etapa = new ArrayList<Etapa>();

    public Ciclista() {
    }

    public Ciclista(short dorsal, String nombre, String nomeq, Date fechanac, Equipo equipo, List<Puerto> puertos,
            List<Llevar> llevar, List<Etapa> etapa) {
        this.dorsal = dorsal;
        this.nombre = nombre;
        this.nomeq = nomeq;
        this.fechanac = fechanac;
        this.equipo = equipo;
        this.puertos = puertos;
        this.llevar = llevar;
        this.etapa = etapa;
    }

    public short getDorsal() {
        return this.dorsal;
    }

    public void setDorsal(short dorsal) {
        this.dorsal = dorsal;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNomeq() {
        return this.nomeq;
    }

    public void setNomeq(String nomeq) {
        this.nomeq = nomeq;
    }

    public Date getfechanac() {
        return this.fechanac;
    }

    public void setfechanac(Date fechanac) {
        this.fechanac = fechanac;
    }

    public Equipo getEquipo() {
        return this.equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public List<Puerto> getPuertos() {
        return this.puertos;
    }

    public void setPuertos(List<Puerto> puertos) {
        this.puertos = puertos;
    }

    public List<Llevar> getLlevar() {
        return this.llevar;
    }

    public void setLlevar(List<Llevar> llevar) {
        this.llevar = llevar;
    }

    public List<Etapa> getEtapa() {
        return this.etapa;
    }

    public void setEtapa(List<Etapa> etapa) {
        this.etapa = etapa;
    }

    public Ciclista dorsal(short dorsal) {
        setDorsal(dorsal);
        return this;
    }

    public Ciclista nombre(String nombre) {
        setNombre(nombre);
        return this;
    }

    public Ciclista nomeq(String nomeq) {
        setNomeq(nomeq);
        return this;
    }

    public Ciclista fechanac(Date fechanac) {
        setfechanac(fechanac);
        return this;
    }

    public Ciclista equipo(Equipo equipo) {
        setEquipo(equipo);
        return this;
    }

    public Ciclista puertos(List<Puerto> puertos) {
        setPuertos(puertos);
        return this;
    }

    public Ciclista llevar(List<Llevar> llevar) {
        setLlevar(llevar);
        return this;
    }

    public Ciclista etapa(List<Etapa> etapa) {
        setEtapa(etapa);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
                " dorsal='" + getDorsal() + "'" +
                ", nombre='" + getNombre() + "'" +
                ", nomeq='" + getNomeq() + "'" +
                ", fechanac='" + getfechanac() + "'" +
                ", equipo='" + getEquipo() + "'" +
                ", pedidos='" + getPuertos() + "'" +
                ", llevar='" + getLlevar() + "'" +
                ", etapa='" + getEtapa() + "'" +
                "}";
    }

}
