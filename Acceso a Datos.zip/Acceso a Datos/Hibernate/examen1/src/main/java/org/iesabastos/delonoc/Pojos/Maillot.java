package org.iesabastos.delonoc.Pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "maillot")
public class Maillot {
    @Column
    private String codigo;
    @Column
    private String tipo;
    @Column
    private String color;
    @Column
    private int premio;

    @OneToMany(mappedBy = "llevar", cascade = CascadeType.ALL)
    private List<Llevar> llevar = new ArrayList<Llevar>();

    public Maillot() {
    }

    public Maillot(String codigo, String tipo, String color, int premio, List<Llevar> llevar) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.color = color;
        this.premio = premio;
        this.llevar = llevar;
    }

    public String getCodigo() {
        return this.codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPremio() {
        return this.premio;
    }

    public void setPremio(int premio) {
        this.premio = premio;
    }

    public List<Llevar> getLlevar() {
        return this.llevar;
    }

    public void setLlevar(List<Llevar> llevar) {
        this.llevar = llevar;
    }

    public Maillot codigo(String codigo) {
        setCodigo(codigo);
        return this;
    }

    public Maillot tipo(String tipo) {
        setTipo(tipo);
        return this;
    }

    public Maillot color(String color) {
        setColor(color);
        return this;
    }

    public Maillot premio(int premio) {
        setPremio(premio);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
                " codigo='" + getCodigo() + "'" +
                ", tipo='" + getTipo() + "'" +
                ", color='" + getColor() + "'" +
                ", premio='" + getPremio() + "'" +
                ", llevar='" + getLlevar() + "'" +
                "}";
    }

}
