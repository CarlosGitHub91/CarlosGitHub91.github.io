package org.iesabastos.delonoc.Interfaz;

import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.iesabastos.delonoc.Pojos.Ciclista;
import org.iesabastos.delonoc.Utils.HibernateUtil;

public class _03CiclistasCiudad {
    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            funcion("Valladolid", sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    }

    public static void funcion(String valor, Session sesion) {
        Query query = sesion.createQuery("from Etapa e WHERE e.salida =:valor or e.llegada =:valor");
        query.setParameter("valor", valor);
        ArrayList<Ciclista> ciclista = (ArrayList<Ciclista>) query.list();
        for (Ciclista c : ciclista) {
            System.out.println(c.getNombre());
        }
    }
}
