package org.iesabastos.delonoc.Pojos;

import javax.persistence.*;

@Entity
@Table(name = "llevar")
public class Llevar {
    @Column
    private short dorsal;
    @Column
    private short netapa;
    @Column
    private String codigo;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "maillot")
    private Maillot maillot;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "ciclista")
    private Ciclista ciclista;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "etapa")
    private Etapa etapa;

    public Llevar() {
    }

    public Llevar(short dorsal, short netapa, String codigo, Maillot maillot, Ciclista ciclista, Etapa etapa) {
        this.dorsal = dorsal;
        this.netapa = netapa;
        this.codigo = codigo;
        this.maillot = maillot;
        this.ciclista = ciclista;
        this.etapa = etapa;
    }

    public short getDorsal() {
        return this.dorsal;
    }

    public void setDorsal(short dorsal) {
        this.dorsal = dorsal;
    }

    public short getNetapa() {
        return this.netapa;
    }

    public void setNetapa(short netapa) {
        this.netapa = netapa;
    }

    public String getCodigo() {
        return this.codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Maillot getMaillot() {
        return this.maillot;
    }

    public void setMaillot(Maillot maillot) {
        this.maillot = maillot;
    }

    public Ciclista getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(Ciclista ciclista) {
        this.ciclista = ciclista;
    }

    public Etapa getEtapa() {
        return this.etapa;
    }

    public void setEtapa(Etapa etapa) {
        this.etapa = etapa;
    }

    public Llevar dorsal(short dorsal) {
        setDorsal(dorsal);
        return this;
    }

    public Llevar netapa(short netapa) {
        setNetapa(netapa);
        return this;
    }

    public Llevar codigo(String codigo) {
        setCodigo(codigo);
        return this;
    }

    public Llevar maillot(Maillot maillot) {
        setMaillot(maillot);
        return this;
    }

    public Llevar ciclista(Ciclista ciclista) {
        setCiclista(ciclista);
        return this;
    }

    public Llevar etapa(Etapa etapa) {
        setEtapa(etapa);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
                " dorsal='" + getDorsal() + "'" +
                ", netapa='" + getNetapa() + "'" +
                ", codigo='" + getCodigo() + "'" +
                ", maillot='" + getMaillot() + "'" +
                ", ciclista='" + getCiclista() + "'" +
                ", etapa='" + getEtapa() + "'" +
                "}";
    }

}
