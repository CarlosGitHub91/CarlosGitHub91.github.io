package org.iesabastos.delonoc.Interfaz;

import java.util.ArrayList;
import java.util.Iterator;

import org.hibernate.Query;
import org.hibernate.Session;
import org.iesabastos.delonoc.Pojos.Ciclista;
import org.iesabastos.delonoc.Pojos.Etapa;
import org.iesabastos.delonoc.Utils.HibernateUtil;

public class _04EtapasCiclistas {
    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            funcion(sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    }

    public static void funcion(Session sesion) {

        Query query = sesion.createQuery("from Etapa e, Ciclista c WHERE e.dorsal=c.dorsal");
        Iterator a = query.list().iterator();
        while (a.hasNext()) {
            Object[] object = (Object[]) a.next();
            System.out.println("Nombre: " + object[1] + " || Nombre de Equipo:" + object[2]);
        }
    }
}
