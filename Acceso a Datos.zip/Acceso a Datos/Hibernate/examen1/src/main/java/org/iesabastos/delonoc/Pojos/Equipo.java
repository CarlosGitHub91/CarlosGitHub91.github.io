package org.iesabastos.delonoc.Pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "equipo")
public class Equipo {
    @Column
    private String nomeq;
    @Column
    private String director;

    @OneToMany(mappedBy = "ciclista", cascade = CascadeType.ALL)
    private List<Ciclista> ciclista = new ArrayList<Ciclista>();

    public Equipo() {
    }

    public Equipo(String nomeq, String director, List<Ciclista> ciclista) {
        this.nomeq = nomeq;
        this.director = director;
        this.ciclista = ciclista;
    }

    public String getNomeq() {
        return this.nomeq;
    }

    public void setNomeq(String nomeq) {
        this.nomeq = nomeq;
    }

    public String getDirector() {
        return this.director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public List<Ciclista> getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(List<Ciclista> ciclista) {
        this.ciclista = ciclista;
    }

    public Equipo nomeq(String nomeq) {
        setNomeq(nomeq);
        return this;
    }

    public Equipo director(String director) {
        setDirector(director);
        return this;
    }

    public Equipo ciclista(List<Ciclista> ciclista) {
        setCiclista(ciclista);
        return this;
    }

    @Override
    public String toString() {
        return "{" +
                " nomeq='" + getNomeq() + "'" +
                ", director='" + getDirector() + "'" +
                ", ciclista='" + getCiclista() + "'" +
                "}";
    }

}
