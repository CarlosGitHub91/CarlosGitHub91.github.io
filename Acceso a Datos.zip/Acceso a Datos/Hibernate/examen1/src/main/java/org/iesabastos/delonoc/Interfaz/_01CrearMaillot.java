package org.iesabastos.delonoc.Interfaz;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.iesabastos.delonoc.Pojos.Maillot;
import org.iesabastos.delonoc.Utils.HibernateUtil;

public class _01CrearMaillot {
    static String codigo;
    static String tipo;
    static String color;
    static int premio;

    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            funcion(sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            e.getStackTrace();
            System.out.println("No se ha podido crear el objeto");
            // TODO: handle exception
        }

    }

    public static void funcion(Session sesion) {

        System.out.println("Introduce el código del maillot: ");
        System.out.println(("Introduce el tipo del maillot"));
        System.out.println(("Introduce el color del maillot"));
        System.out.println(("Introduce el premio del maillot"));
        try (Scanner scan = new Scanner(System.in)) {
            codigo = scan.next();
            tipo = scan.next();
            color = scan.next();
            premio = scan.nextInt();
        } catch (Exception e) {
            System.out.println("Error de Scanner");
        }

        Query query = sesion.createQuery("from Maillot");
        Maillot m = (Maillot) query.uniqueResult();

        boolean cOk = false;
        if (m != null) {
            System.out.println("El maillot ya existe");
        } else {
            cOk = true;
        }
        while (cOk == true) {
            Maillot maillot = new Maillot();
            maillot.setCodigo(codigo);
            maillot.setColor(tipo);
            maillot.setTipo(color);
            maillot.setPremio(premio);
            sesion.save(maillot);
        }
    }
}
