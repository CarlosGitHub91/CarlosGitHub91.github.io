package org.iesabastos.dam.datos.delonoc;

import org.hibernate.*;

public class _01c02PuertosGanadosPorCiclista {
    public static void funcion(int valor, Session sesion) {

        Query query = sesion.createQuery("from Ciclista c WHERE c.dorsal =: valor");
        query.setParameter("dorsal", valor);
        Ciclista c = (Ciclista) query.uniqueResult();
        for (Puerto p : c.getPuerto())
            System.out.println(c.getNombre() + "" + p.getAltura() + "" + p.getCategoria());
    }

}
