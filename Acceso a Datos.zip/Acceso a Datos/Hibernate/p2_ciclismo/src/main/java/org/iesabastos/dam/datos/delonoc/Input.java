package org.iesabastos.dam.datos.delonoc;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.*;

public class Input {
    public static String getString(String prompt) {
        System.out.println(prompt);
        while (true) {
            try {
                String s = new Scanner(System.in).nextLine();
                return s;
            } catch (Exception ne) {
                System.out.println(prompt);
            }
        }
    }

    public static short getShort(String prompt) {
        System.out.println(prompt);
        while (true) {
            try {
                return Short.parseShort(new Scanner(System.in).next());
            } catch (NumberFormatException ne) {
                System.out.println(prompt);
            }
        }
    }

    public static Date getDate(String prompt) {
        while (true) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String s = getString(prompt);
                boolean b = Pattern.matches("^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$", s);
                if (b) {
                    Date convertedCurrentDate = sdf.parse(s);
                    return convertedCurrentDate;
                } else {
                    Date convertedCurrentDate = sdf.parse("error");
                    return convertedCurrentDate;
                }

            } catch (ParseException e) {
                System.out.println("El formato es yyyy-MM-dd");
            }
        }
    }
}