package org.iesabastos.dam.datos.delonoc;

import org.hibernate.*;

public class _03EliminarEquipo {
    public static void funcion(Session sesion) {
        Query query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", Input.getString("Introduce el nombre del equipo"));
        Equipo e = (Equipo) query.uniqueResult();

        if (e == null) {
            System.out.println("El equipo no existe");
        } else {
            sesion.delete(e);
        }
    }
}
