package org.iesabastos.dam.datos.delonoc;

import org.hibernate.*;

public class _01b02EtapasGanadasPorCiclista {
    public static void funcion(int valor, Session sesion) {

        Query query = sesion.createQuery("from Ciclista c WHERE c.dorsal =:valor");
        query.setParameter("valor", valor);
        Etapa e = (Etapa) query.uniqueResult();
        System.out.println(e.getSalida() + "" + e.getLlegada());

    }
}
