package org.iesabastos.dam.datos.delonoc;

import java.util.Scanner;

import org.hibernate.*;

public class _02aCrearEquipo {
    static String nomeq;
    static String director;

    public static void funcion(String valor, Session sesion) {
        System.out.println("Introduce el nombre del equipo: ");
        System.out.println(("Introduce el nombre del empleado"));
        try (Scanner scan = new Scanner(System.in)) {
            nomeq = scan.next();
            director = scan.next();
        } catch (Exception e) {
            System.out.println("Error de Scanner");
        }
        Query query = sesion.createQuery("from Equipo e WHERE e.nomeq =: nomeq");
        query.setParameter("nombre", nomeq);
        Equipo e = (Equipo) query.uniqueResult();

        if (e.getNomeq() == valor) {
            System.out.println("El equipo ya existe");
        } else if (e.getNomeq() != valor) {
            Equipo equipo = new Equipo();
            equipo.setNomeq(valor);
            equipo.setDirector("Nuevo director");
            sesion.save(equipo);
        }
    }

}
