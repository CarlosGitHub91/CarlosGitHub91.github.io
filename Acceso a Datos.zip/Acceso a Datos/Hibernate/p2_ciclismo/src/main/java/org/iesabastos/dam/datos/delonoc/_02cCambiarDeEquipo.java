package org.iesabastos.dam.datos.delonoc;

import java.util.Scanner;

import org.hibernate.*;

public class _02cCambiarDeEquipo {
    static int dorsal;
    static String nomeq;

    public static void funcion(String valor, Session sesion) {
        System.out.println("Introduce el numero del dorsal: ");
        System.out.println(("Introduce el nombre del ciclista: "));
        System.out.println("Introduce el nombre del equipo");
        try (Scanner scan = new Scanner(System.in)) {
            dorsal = scan.nextInt();
            nomeq = scan.next();
        } catch (Exception e) {
            System.out.println("Error de Scanner");
        }
        Query query1 = sesion.createQuery("from Ciclista c WHERE c.dorsal =:dorsal");
        query1.setParameter("dorsal", dorsal);
        Ciclista c = (Ciclista) query1.uniqueResult();
        Query query2 = sesion.createQuery("from Equipo e WHERE e.nomeq =:nomeq");
        query2.setParameter("nomeq", nomeq);
        Equipo e = (Equipo) query2.uniqueResult();
        Ciclista ciclista = new Ciclista();
        if (c.getDorsal() == dorsal) {
            System.out.println("El ciclista ya existe");
        } else if (e.getNomeq() == nomeq) {
            System.out.println("El equipo ya existe");
        } else if (e.getNomeq() == c.getNombre()) {
            System.out.println("El equipo es el mismo");
        } else {
            ciclista.setEquipo(e);
            sesion.save(ciclista);
        }

    }
}
