package org.iesabastos.dam.datos.delonoc;

import java.util.Scanner;

import org.hibernate.*;

public class _02bModificarEquipo {
    static String nomeq;
    static String director;

    public static void funcion(String valor, Session sesion) {
        System.out.println("Introduce el nombre del equipo: ");
        System.out.println(("Introduce el nombre del empleado"));
        try (Scanner scan = new Scanner(System.in)) {
            nomeq = scan.next();
            director = scan.next();
        } catch (Exception e) {
            System.out.println("Error de Scanner");
        }
        Query query1 = sesion.createQuery("from Equipo e WHERE e.nomeq =: nomeq");
        query1.setParameter("nomeq", nomeq);
        Equipo e = (Equipo) query1.uniqueResult();
        Equipo equipo = new Equipo();
        if (e.getNomeq() == nomeq) {
            System.out.println("El equipo ya existe");
        } else {
            equipo.setDirector(director);
            sesion.save(equipo);

        }

    }
}
