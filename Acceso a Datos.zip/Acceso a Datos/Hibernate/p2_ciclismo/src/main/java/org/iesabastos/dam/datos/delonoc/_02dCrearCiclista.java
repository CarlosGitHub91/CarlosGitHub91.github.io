package org.iesabastos.dam.datos.delonoc;

import java.util.Date;

import org.hibernate.*;

public class _02dCrearCiclista {
    public static void funcion(Session sesion) {
        short dorsal = Input.getShort("Introduce el dorsal del ciclista");
        String nombre = Input.getString("Introduce el nombre del ciclista");
        String nEquipo = Input.getString("Introduce el nombre del equipo");
        Date fecha = Input.getDate("Introduce la fecha de nacimiento del ciclista (yyyy-mm-dd)");

        boolean cOk = false;

        Query query = sesion.createQuery("from Ciclista t WHERE t.dorsal =:valor");
        query.setParameter("valor", dorsal);
        Ciclista c = (Ciclista) query.uniqueResult();

        query = sesion.createQuery("from Equipo t WHERE t.nomeq =:valor");
        query.setParameter("valor", nEquipo);
        Equipo e = (Equipo) query.uniqueResult();

        if (c != null) {
            System.out.println("El dorsal ya existe");
        } else {
            cOk = true;
        }

        if (e == null) {
            System.out.println("El equipo no existe");
        } else if (cOk) {
            Ciclista n = new Ciclista();
            n.setDorsal(dorsal);
            n.setNombre(nombre);
            n.setEquipo(e);
            n.setNacimiento(fecha);
            sesion.save(n);
        }
    }

}
