package org.iesabastos.dam.datos.delonoc;

import org.hibernate.*;


public class App {
    public static void main(String[] args) {
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();

            sesion.beginTransaction();

            _01b01DirectorDelCiclista.funcion(1, sesion);
            // _01a01DirectorDelCiclista.funcion(10,sesion);
            // _01a02CiclistasDeEquipo.funcion(10,sesion);
            // _01b01GanadorDeEtapa.funcion(10,sesion);
            //_01b02EtapasGanadasPorCiclista.funcion(1,sesion);
            // _01b03EtapasGanadasPorEquipo.funcion(10,sesion);
            // _01c01GanadorDePuerto.funcion("Banesto",sesion);
            //_01c02PuertosGanadosPorCiclista.funcion(10,sesion);
            //_02aCrearEquipo.funcion("Bancaja", sesion);
            //_02bModificarEquipo.funcion("Banesto",sesion);
            // _02cCambiarDeEquipo.funcion(sesion);
            // _02dCrearCiclista.funcion(sesion);
            // _03EliminarEquipo.funcion(sesion);
            // _04EliminarEquipoYCambiarCiclistas.funcion(sesion);
            // _05HQLBasicas.funcion(sesion);
            // _06HQLVariasTablas.funcion(sesion);

            sesion.getTransaction().commit();
            sesion.close();

        } catch (Exception e) {
            // TODO: handle exception
        }

    }
}
