package org.iesabastos.dam.datos.delonoc;

import org.hibernate.*;

public class _01b01GanadorDeEtapa {
    public static void funcion(int valor, Session sesion) {

        Query query = sesion.createQuery("from Etapa e WHERE e.netapa =:valor");
        query.setParameter("valor", valor);
        Etapa e = (Etapa) query.uniqueResult();
        System.out.println(e.getCiclista().getNombre());
    }
}
