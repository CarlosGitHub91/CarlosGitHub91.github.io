package org.iesabastos.dam.datos.delonoc;

import org.hibernate.*;

public class _01a02CiclistasDeEquipo {
    
    public static void funcion(String valor, Session sesion) {

        Query query = sesion.createQuery("from Equipo e WHERE e.nomeq =:valor");
        query.setParameter("valor", valor);
        Equipo e = (Equipo) query.uniqueResult();
        for (Ciclista c : e.getEquipos()) {
            System.out.println(c.getNombre());
        }
    }
}
