package org.iesabastos.dam.datos.delonoc;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "equipo")
public class Equipo implements Serializable {
    @Id
    @Column
    private String nomeq;
    @Column
    private String director;

    @OneToMany(mappedBy = "equipo", cascade = CascadeType.DETACH)
    private List<Ciclista> equipos = new ArrayList<Ciclista>();

    public Equipo() {
    }

    public String getNomeq() {
        return this.nomeq;
    }

    public void setNomeq(String nomeq) {
        this.nomeq = nomeq;
    }

    public String getDirector() {
        return this.director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public List<Ciclista> getEquipos() {
        return this.equipos;
    }

    public void setEquipos(List<Ciclista> equipos) {
        this.equipos = equipos;
    }
}
