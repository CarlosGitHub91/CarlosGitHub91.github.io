package org.iesabastos.dam.datos.delonoc;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "etapa")
public class Etapa implements Serializable{
    @Id
    @Column
    private short netapa;
    @Column
    private short km;
    @Column
    private String salida;
    @Column
    private String llegada;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "dorsal")
    private Ciclista ciclista;

    @OneToMany(mappedBy = "ciclista", cascade = CascadeType.DETACH)
    private List<Puerto> puerto = new ArrayList<Puerto>();

    public Etapa() {
    }

    public short getNetapa() {
        return this.netapa;
    }

    public void setNetapa(short netapa) {
        this.netapa = netapa;
    }

    public short getKm() {
        return this.km;
    }

    public void setKm(short km) {
        this.km = km;
    }

    public String getSalida() {
        return this.salida;
    }

    public void setSalida(String salida) {
        this.salida = salida;
    }

    public String getLlegada() {
        return this.llegada;
    }

    public void setLlegada(String llegada) {
        this.llegada = llegada;
    }

    public Ciclista getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(Ciclista ciclista) {
        this.ciclista = ciclista;
    }

    public List<Puerto> getPuerto() {
        return this.puerto;
    }

    public void setPuerto(List<Puerto> puerto) {
        this.puerto = puerto;
    }
    
}
