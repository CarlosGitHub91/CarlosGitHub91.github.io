package org.iesabastos.dam.datos.delonoc;

import java.util.Iterator;

import org.hibernate.*;

public class _06HQLVariasTablas {

    public static void funcion(Session sesion) {
        Query query = sesion.createQuery(
                "select e.salida,e.llegada,c.nombre from Etapa e inner join e.ciclista as c");
        Iterator a = query.list().iterator();

        while (a.hasNext()) {
            Object[] object = (Object[]) a.next();
            System.out.println("Salida: " + object[0] + " || Llegada:" + object[1] + " || Ganador: " + object[2]);
        }

        query = sesion.createQuery(
                "select e.nomeq,e.director,count(c.nombre) from Equipo e inner join e.equipos as c group by e.nomeq");
        Iterator b = query.list().iterator();

        while (b.hasNext()) {
            Object[] object = (Object[]) b.next();
            System.out.println("Nombre: " + object[0] + " || Director:" + object[1] + " || Nº Ciclistas: " + object[2]);
        }
    }
}
