import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDB {

    Connection establishConnection() throws SQLException {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/tienda", "root", "admin");
            System.out.println("Connection made!");
            System.out.println("Schema Name:"+conn.getSchema()+"\n");
        } catch (SQLException sqle) {
            System.err.println("SQL Exception thrown while making connection");
            printSQLException(sqle);
        }
        return conn;
    }

    static void printSQLException(SQLException sqle) {
    }

    public static void main(String[] args) {
        ConnectDB cdb= new ConnectDB();
        Connection myconn=null;
        try{
            myconn=cdb.establishConnection();
            if(myconn!=null) System.out.println("Successfully connected to " + myconn.getSchema());
        }catch (SQLException e) {
              ConnectDB.printSQLException(e);
        } catch (Exception e) {
          e.printStackTrace(System.err);
        } 

    }


}