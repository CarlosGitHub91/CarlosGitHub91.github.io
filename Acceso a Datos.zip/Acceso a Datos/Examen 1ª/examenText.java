import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class examenText {
    private Connection establishConnection() throws SQLException {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/tienda", "root", "admin");
            System.out.println("Connection made!");
            System.out.println("Schema Name:" + conn.getSchema() + "\n");
        } catch (SQLException sqle) {
            System.err.println("SQL Exception thrown while making connection");
            printSQLException(sqle);
        }
        return conn;
    }

    private void printSQLException(SQLException sqle) {
    }

    public static void escribirFichero() throws IOException {
        ConexionExamen cdb = new ConexionExamen();
        Connection con = null;
        String sentenciaSql = "SELECT * from tienda";
        PreparedStatement sentencia = null;
        ResultSet resultado = null;
        FileWriter fichero = null;
        PrintWriter escritor = null;
        fichero = new FileWriter("C:/Users/User/Desktop/2º DAM/Acceso a Datos Ejercicios/Examen 1ª/examen.txt");
        escritor = new PrintWriter(fichero);
        try {
            con = cdb.establishConnection();
            sentencia = con.prepareStatement(sentenciaSql);
            resultado = sentencia.executeQuery();
            while (resultado.next()) {
            int partnumber = resultado.getInt(1);
            String desc = resultado.getString(2);
            String col = resultado.getString(3);
            String fam = resultado.getString(4);
            String prec = resultado.getString(5);
            escritor.println("Part_number: " + partnumber + "\nDescripcion:" + desc + "\nColor: " + col
                    + "\nFamilia: " + fam + "\nPrecio: " + prec);
            }

            fichero.close();
            sentencia.close();
            resultado.close();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
    }

    public static void leerFichero() {
        File archivo = null;
       FileReader fr = null;
       BufferedReader br = null;
 
       try {
          // Apertura del fichero y creacion de BufferedReader para poder
          // hacer una lectura comoda (disponer del metodo readLine()).
          archivo = new File ("C:/Users/User/Desktop/2º DAM/Acceso a Datos Ejercicios/Examen 1ª/examen.txt");
          fr = new FileReader (archivo);
          br = new BufferedReader(fr);
 
          // Lectura del fichero
          String linea;
          while((linea=br.readLine())!=null)
             System.out.println(linea);
       }
       catch(Exception e){
          e.printStackTrace();
       }finally{
          // En el finally cerramos el fichero, para asegurarnos
          // que se cierra tanto si todo va bien como si salta 
          // una excepcion.
          try{                    
             if( null != fr ){   
                fr.close();     
             }                  
          }catch (Exception e2){ 
             e2.printStackTrace();
          }
       }
    }
}
