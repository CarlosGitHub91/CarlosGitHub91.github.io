import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ConexionExamen {
    static Connection conexion;

    Connection establishConnection() throws SQLException {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/tienda", "root", "admin");
            System.out.println("Connection made!");
            System.out.println("Schema Name:" + conn.getSchema() + "\n");
        } catch (SQLException sqle) {
            System.err.println("SQL Exception thrown while making connection");
            printSQLException(sqle);
        }
        return conn;
    }

    private static void printSQLException(SQLException sqle) {
    }

    public static void main(String[] args) {
        
        /*String user, passwd;
        Scanner scan = new Scanner(System.in);
        
        
        do {
        System.out.println("Introduce usuario:");
        user = scan.nextLine();
        System.out.println("Introduce contraseña:");
        passwd = scan.nextLine();
        
        if (user.equals("root") && passwd.equals("admin")) {
        System.out.println("Contraseña correcta");
        } else {
        System.out.println("Contraseña incorrecta");
        }
        
        } while (!user.equals("root") && passwd.equals("admin"));
        
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        conexion = DriverManager.getConnection(
        "jdbc:mysql://localhost:3306/pruebas",
        "root", "admin");
        } catch (ClassNotFoundException cnfe)
        
        {
        cnfe.printStackTrace();
        } catch (SQLException sqle) {
        sqle.printStackTrace();
        }*/
         
        //create_table();
        insertar();
        //modificar();
        //consultar();
        //eliminar();
        
    }

    public static void create_table() {
        ConexionExamen cdb = new ConexionExamen();
        Connection myconn = null;
        try {
            myconn = cdb.establishConnection();
            PreparedStatement stmt = null;
            try {
                stmt = myconn.prepareStatement(
                        "CREATE TABLE tienda (Part_number INT(20), Descripcion varchar(50), Color varchar(50), Familia varchar(50),Precio varchar(50))");
                stmt.execute();
                stmt.close();
                System.out.println("Tabla Creada");
            } catch (SQLException sqle) {
                System.out.println("Error en la ejecución: "
                        + sqle.getErrorCode() + " " + sqle.getMessage());
            }

            if (myconn != null)
                System.out.println("Successfully connected to " + myconn.getSchema());
        } catch (SQLException e) {
            ConnectDB.printSQLException(e);
        } catch (Exception e) {
            e.printStackTrace(System.err);
        }

    }

    public static void insertar() {
        String sentenciaSql = "INSERT INTO tienda (Part_number,Descripcion,Color,Familia,Precio) VALUES (?,?,?,?,?)";
        PreparedStatement sentencia = null;
        ConexionExamen cdb = new ConexionExamen();
        Connection con = null;
        try {
            con = cdb.establishConnection();
            sentencia = con.prepareStatement(sentenciaSql);
            sentencia.setInt(1, 2);
            sentencia.setString(2, "Ropa");
            sentencia.setString(3, "Negra");
            sentencia.setString(4, "Textil");
            sentencia.setString(5, "20000");
            System.out.println("Valores insertados");
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }

    public static void modificar() {
        ConexionExamen cdb = new ConexionExamen();
        Connection con = null;
        String sentenciaSql = "UPDATE tienda SET Descripcion = ? WHERE Descripcion = ?";
        PreparedStatement sentencia = null;

        try {
            con = cdb.establishConnection();
            sentencia = con.prepareStatement(sentenciaSql);
            sentencia.setString(1, "Calzoncillos");
            sentencia.setString(2, "Ropa");
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }

    public static void consultar() {
        ConexionExamen cdb = new ConexionExamen();
        Connection con = null;
        String sentenciaSql = "SELECT * from tienda";
        PreparedStatement sentencia = null;
        ResultSet resultado = null;

        try {
            con = cdb.establishConnection();
            sentencia = con.prepareStatement(sentenciaSql);
            resultado = sentencia.executeQuery();
            while (resultado.next()) {
                System.out.println(
                        "Part_number: " + resultado.getInt(1) +
                        "|| Descripción: " + resultado.getString(2) +
                        "|| Color: " + resultado.getString(3) +
                        "|| Familia: " + resultado.getString(4) +
                        "|| Precio: " + resultado.getString(5));
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                    resultado.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }

        }
    }

    public static void eliminar() {
        String sentenciaSql = "DELETE FROM tienda WHERE nombre = ?";
        PreparedStatement sentencia = null;

        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, "Chocolate");
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }
}
