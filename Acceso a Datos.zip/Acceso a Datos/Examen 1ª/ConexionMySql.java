import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ConexionMySql {
    static Connection conexion;

    public static void main(String[] args) {
        String user, passwd;
        Scanner scan = new Scanner(System.in);

        /*
         * do {
         * System.out.println("Introduce usuario:");
         * user = scan.nextLine();
         * System.out.println("Introduce contraseña:");
         * passwd = scan.nextLine();
         * 
         * if (user.equals("root") && passwd.equals("admin")) {
         * System.out.println("Contraseña correcta");
         * } else {
         * System.out.println("Contraseña incorrecta");
         * }
         * 
         * } while (!user.equals("root") && passwd.equals("admin"));
         */
        Connection con=null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/pruebas",
                    "root", "admin");
        } catch (ClassNotFoundException cnfe)

        {
            cnfe.printStackTrace();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        conexion=con;
        
        insertar();
        /*modificar();
         
        consultar();
        eliminar();*/
    }

    public static void insertar() {
        String sentenciaSql = "INSERT INTO conectados (ID, nombre) VALUES (?, ?)";
        PreparedStatement sentencia = null;

        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setInt(1, 1001);
            sentencia.setString(2, "Chocolate");
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }

    public static void modificar() {
        String sentenciaSql = "UPDATE conectados SET nombre = ? WHERE nombre = ?";

        PreparedStatement sentencia = null;

        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, "Carlos");
            sentencia.setString(2, "Skelly");
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }

    public static void consultar() {
        String sentenciaSql = "SELECT * from conectados";
        PreparedStatement sentencia = null;
        ResultSet resultado = null;

        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            resultado = sentencia.executeQuery();
            while (resultado.next()) {
                System.out.println("ID: " + resultado.getInt(1) +
                        "|| Nombre: " + resultado.getString(2) +
                        "|| Apellido: " + resultado.getString(3) +
                        "|| Email: " + resultado.getString(4) +
                        "|| Género: " + resultado.getString(5) +
                        "|| Ip: " + resultado.getString(6));
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                    resultado.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }

        }
    }

    public static void eliminar() {
        String sentenciaSql = "DELETE FROM conectados WHERE nombre = ?";
        PreparedStatement sentencia = null;

        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            sentencia.setString(1, "Chocolate");
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }
    }
}
