import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class examenXML {
    private Connection establishConnection() throws SQLException {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/tienda", "root", "admin");
            System.out.println("Connection made!");
            System.out.println("Schema Name:" + conn.getSchema() + "\n");
        } catch (SQLException sqle) {
            System.err.println("SQL Exception thrown while making connection");
            printSQLException(sqle);
        }
        return conn;
    }

    private void printSQLException(SQLException sqle) {
    }

    public static void escribirXml(String string)
            throws ParserConfigurationException, TransformerException {
        ConexionExamen cdb = new ConexionExamen();
        Connection con = null;
        String sentenciaSql = "SELECT * from tienda";
        PreparedStatement sentencia = null;
        ResultSet resultado = null;
        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        Document document = documentBuilder.newDocument();

        Element xml = document.createElement("xml");
        document.appendChild(xml);

        Element productos = document.createElement("productos");
        xml.appendChild(productos);

        try {
            con = cdb.establishConnection();
            sentencia = con.prepareStatement(sentenciaSql);
            resultado = sentencia.executeQuery();
            while (resultado.next()) {
                int partnumber = resultado.getInt(1);
                String desc = resultado.getString(2);
                String col = resultado.getString(3);
                String fam = resultado.getString(4);
                String prec = resultado.getString(5);
                Element producto = document.createElement("producto");
                productos.appendChild(producto);

                Element part_number = document.createElement("Part_number");
                part_number.appendChild(document.createTextNode(String.valueOf(partnumber)));
                producto.appendChild(part_number);

                Element descripcion = document.createElement("Descripcion");
                descripcion.appendChild(document.createTextNode(desc));
                producto.appendChild(descripcion);

                Element color = document.createElement("Color");
                color.appendChild(document.createTextNode(col));
                producto.appendChild(color);

                Element familia = document.createElement("Familia");
                familia.appendChild(document.createTextNode(fam));
                producto.appendChild(familia);

                Element precio = document.createElement("Precio");
                precio.appendChild(document.createTextNode(prec));
                producto.appendChild(precio);

            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                    resultado.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }

        }

        // create the xml file
        // transform the DOM Object to an XML File

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource domSource = new DOMSource(document);

        StreamResult streamResult = new StreamResult(string);

        // If you use
        // StreamResult result = new StreamResult(System.out);
        // the output will be pushed to the standard output ...
        // You can use that for debugging

        transformer.transform(domSource, streamResult);

        System.out.println("Done creating XML File");
    }

    public static void leerXml() {
        // Importa el documentoXml al formato Document
        try {
            File archivo = new File("C:/Users/User/Desktop/2º DAM/Acceso a Datos Ejercicios/Examen 1ª/examen.xml");
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = dbf.newDocumentBuilder();
            Document document = documentBuilder.parse(archivo);

            document.getDocumentElement().normalize();
            //System.out.println("Elemento raiz:" + document.getDocumentElement().getNodeName());
            NodeList productos= document.getElementsByTagName("producto");

            for (int temp = 0; temp < productos.getLength(); temp++) {
                Node nodo = productos.item(temp);
                //System.out.println("Elementos:" + nodo.getNodeName());
                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) nodo;
                    System.out.println("Part_number: " + element.getElementsByTagName("Part_number").item(0).getTextContent());
                    System.out.println("Descripcion: " + element.getElementsByTagName("Descripcion").item(0).getTextContent());
                    System.out.println("Color: " + element.getElementsByTagName("Color").item(0).getTextContent());
                    System.out.println("Familia: " + element.getElementsByTagName("Familia").item(0).getTextContent());
                    System.out.println("Precio: " + element.getElementsByTagName("Precio").item(0).getTextContent());
                    System.out.println("\n");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void leerFicheroXML() {
        File archivo = null;
       FileReader fr = null;
       BufferedReader br = null;
 
       try {
          // Apertura del fichero y creacion de BufferedReader para poder
          // hacer una lectura comoda (disponer del metodo readLine()).
          archivo = new File ("C:/Users/User/Desktop/2º DAM/Acceso a Datos Ejercicios/Examen 1ª/examen.xml");
          fr = new FileReader (archivo);
          br = new BufferedReader(fr);
 
          // Lectura del fichero
          String linea;
          while((linea=br.readLine())!=null)
             System.out.println(linea);
       }
       catch(Exception e){
          e.printStackTrace();
       }finally{
          // En el finally cerramos el fichero, para asegurarnos
          // que se cierra tanto si todo va bien como si salta 
          // una excepcion.
          try{                    
             if( null != fr ){   
                fr.close();     
             }                  
          }catch (Exception e2){ 
             e2.printStackTrace();
          }
       }
    }
}