import java.io.IOException;
import java.sql.SQLException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

public class examen {
    public static void main(String[] args)
            throws SAXException, IOException, ParserConfigurationException, TransformerException, SQLException {

        String[] dato = { "producto" };
        String[] info = { "Part_number", "Descripcion", "Color", "Familia", "Precio" };
        examenXML examenXML = new examenXML();
        //examenXML.escribirXml("C:/Users/User/Desktop/2º DAM/Acceso a Datos Ejercicios/Examen 1ª/examen.xml");
        //examenXML.leerXml();
        examenText examenText = new examenText();
        //examenText.escribirFichero();
        examenText.leerFichero();
        
    }
}
