import java.io.IOException;
import java.util.Properties;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class Configuracion {
    private static String miUsuario = "";
    private static String miContrasena = "";
    private static String elServidor = "";
    private static String elPuerto = "3000";

    public static void main(String[] args) {
        escribir_ficheros();
        leer_ficheros();
    }

    public static void escribir_ficheros() {
        Properties configuracion = new Properties();
        configuracion.setProperty("user", miUsuario);
        configuracion.setProperty("password", miContrasena);
        configuracion.setProperty("server", elServidor);
        configuracion.setProperty("port", elPuerto);
        try {
            configuracion.store(new FileOutputStream("configuracion.props"), "Fichero de configuracion");
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public static void leer_ficheros() {
        Properties configuracion = new Properties();
        try {
            configuracion.load(new FileInputStream("configuracion.props"));
            String usuario = configuracion.getProperty("user");
            String password = configuracion.getProperty("password");
            String servidor = configuracion.getProperty("server");
            int puerto = Integer.valueOf(configuracion.getProperty("port"));
        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
