package ies.abastos.daniel.Interfaz;

import java.util.Iterator;

import org.hibernate.*;
import ies.abastos.daniel.Utils.HibernateUtil;

public class _04EtapasCiclistas {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

            Query query = sesion.createQuery(
                    "select e.netapa,c.nombre,eq.nomeq from Etapa e inner join e.ciclista as c inner join c.equipo as eq order by e.netapa");
            Iterator a = query.list().iterator();

            while (a.hasNext()) {
                Object[] object = (Object[]) a.next();
                System.out.println("Etapa: " + object[0] + " || Ganador:" + object[1] + " || Equipo: " + object[2]);
            }
            sesion.getTransaction().commit();
            sesion.close();
            // System.out.println( "Todo OK!" );
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("*****************Error*****************");
        }
    }
}
