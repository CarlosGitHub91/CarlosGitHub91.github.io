package ies.abastos.daniel.Interfaz;

import org.hibernate.*;

import ies.abastos.daniel.Pojos.Maillot;
import ies.abastos.daniel.Utils.Input;
import ies.abastos.daniel.Utils.HibernateUtil;

public class _01CrearMaillot {

    public static void main(String[] args) {
        System.out.println("Hello World!");
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

            String codigo = Input.getString("Introduce el codigo");
            String tipo = Input.getString("Introduce el tipo");
            String color = Input.getString("Introduce el color");
            int premio = Input.getInt("Introduce el premio");

            Query query = sesion.createQuery("from Maillot t WHERE t.codigo =:valor");
            query.setParameter("valor", codigo);
            Maillot m = (Maillot) query.uniqueResult();

            if (m != null) {
                System.out.println("El maillot ya existe");
            } else {
                Maillot n = new Maillot();
                n.setCodigo(codigo);
                n.setTipo(tipo);
                n.setColor(color);
                n.setPremio(premio);
                sesion.save(n);
                System.out.println("Maillot introducido");
            }
            sesion.getTransaction().commit();
            sesion.close();
            // System.out.println( "Todo OK!" );
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("*****************Error*****************");
        }
    }
}
