package ies.abastos.daniel.Interfaz;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.*;

import ies.abastos.daniel.Pojos.Ciclista;
import ies.abastos.daniel.Pojos.Equipo;
import ies.abastos.daniel.Utils.HibernateUtil;

public class _05CrearEquipo {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

            Equipo vip = new Equipo();
            vip.setNomeq("VIP");
            vip.setDirector("Edvard Grieg");
            sesion.save(vip);

            Query query = sesion.createQuery("from Ciclista");
            List<Ciclista> list = (ArrayList<Ciclista>) query.list();

            for (Ciclista cic : list) {
                for (int i = 0; i < cic.getLlevar().size(); i++) {
                    if (cic.getLlevar().get(i).getMaillot().getPremio() >= 40000) {
                        cic.setEquipo(vip);
                        sesion.save(cic);
                    }
                }
            }

            sesion.getTransaction().commit();
            sesion.close();
            // System.out.println( "Todo OK!" );
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("*****************Error*****************");
        }
    }
}
