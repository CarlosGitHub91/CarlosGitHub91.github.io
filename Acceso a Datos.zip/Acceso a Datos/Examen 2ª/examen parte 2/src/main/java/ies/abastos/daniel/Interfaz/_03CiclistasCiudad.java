package ies.abastos.daniel.Interfaz;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.*;

import ies.abastos.daniel.Pojos.Etapa;
import ies.abastos.daniel.Utils.HibernateUtil;
import ies.abastos.daniel.Utils.Input;

public class _03CiclistasCiudad {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

            String ciudad = Input.getString("Introduce una ciudad");

            Query query = sesion.createQuery("from Etapa t WHERE t.salida =:valor or t.llegada =:valor");
            query.setParameter("valor", ciudad);
            List<Etapa> list = (ArrayList<Etapa>) query.list();

            for (Etapa etapa : list) {
                System.out.println(etapa.getCiclista().getNombre() + " gano la etapa: " + etapa.getNetapa());
            }

            sesion.getTransaction().commit();
            sesion.close();
            // System.out.println( "Todo OK!" );
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("*****************Error*****************");
        }
    }
}
