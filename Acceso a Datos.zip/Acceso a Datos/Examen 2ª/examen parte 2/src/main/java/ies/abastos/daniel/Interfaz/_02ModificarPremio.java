package ies.abastos.daniel.Interfaz;

import java.util.List;

import org.hibernate.*;

import ies.abastos.daniel.Pojos.Maillot;
import ies.abastos.daniel.Utils.HibernateUtil;

public class _02ModificarPremio {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        try {
            HibernateUtil.buildSessionFactory();
            HibernateUtil.openSession();

            Session sesion = HibernateUtil.getCurrentSession();
            sesion.beginTransaction();

            Query query = sesion.createQuery("from Maillot");
            List<Maillot> premioPst = (List<Maillot>) query.list();

            for (Maillot pst : premioPst) {
                pst.setPremio((int) Math.floor(pst.getPremio() / 166.386));
                sesion.save(pst);
            }
            System.out.println("Se han modificado " + premioPst.size() + " Maillots");

            sesion.getTransaction().commit();
            sesion.close();
            // System.out.println( "Todo OK!" );
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("*****************Error*****************");
        }
    }
}