package ies.abastos.daniel.Pojos;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "ciclista")
public class Ciclista implements Serializable {
    @Id
    @Column
    private byte dorsal;
    @Column
    private String nombre;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "nomeq")
    private Equipo equipo;
    @Column
    private Date fechanac;

    @OneToMany(mappedBy = "ciclista", cascade = CascadeType.DETACH)
    private List<Etapa> etapa = new ArrayList<Etapa>();
    @OneToMany(mappedBy = "ciclista", cascade = CascadeType.DETACH)
    private List<Puerto> puerto = new ArrayList<Puerto>();
    @OneToMany(mappedBy = "ciclista", cascade = CascadeType.DETACH)
    private List<Llevar> llevar = new ArrayList<Llevar>();

    public Ciclista() {
    }

    public byte getDorsal() {
        return this.dorsal;
    }

    public void setDorsal(byte dorsal) {
        this.dorsal = dorsal;
    }

    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Equipo getEquipo() {
        return this.equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public Date getFechanac() {
        return this.fechanac;
    }

    public void setFechanac(Date fechanac) {
        this.fechanac = fechanac;
    }

    public List<Etapa> getEtapa() {
        return this.etapa;
    }

    public void setEtapa(List<Etapa> etapa) {
        this.etapa = etapa;
    }

    public List<Puerto> getPuerto() {
        return this.puerto;
    }

    public void setPuerto(List<Puerto> puerto) {
        this.puerto = puerto;
    }

    public List<Llevar> getLlevar() {
        return this.llevar;
    }

    public void setLlevar(List<Llevar> llevar) {
        this.llevar = llevar;
    }

}
