package ies.abastos.daniel.Pojos;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "llevar")
public class Llevar implements Serializable {
    @Id
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "dorsal")
    private Ciclista ciclista;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "netapa")
    private Etapa etapa;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "codigo")
    private Maillot maillot;

    public Llevar() {
    }

    public Ciclista getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(Ciclista ciclista) {
        this.ciclista = ciclista;
    }

    public Etapa getEtapa() {
        return this.etapa;
    }

    public void setEtapa(Etapa etapa) {
        this.etapa = etapa;
    }

    public Maillot getMaillot() {
        return this.maillot;
    }

    public void setMaillot(Maillot maillot) {
        this.maillot = maillot;
    }

}
