package ies.abastos.daniel.Pojos;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "maillot")
public class Maillot implements Serializable {
    @Id
    @Column
    private String codigo;
    @Column
    private String tipo;
    @Column
    private String color;
    @Column
    private int premio;

    @OneToMany(mappedBy = "maillot", cascade = CascadeType.DETACH)
    private List<Llevar> llevar = new ArrayList<Llevar>();

    public Maillot() {
    }

    public String getCodigo() {
        return this.codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return this.tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getColor() {
        return this.color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPremio() {
        return this.premio;
    }

    public void setPremio(int premio) {
        this.premio = premio;
    }

    public List<Llevar> getLlevar() {
        return this.llevar;
    }

    public void setLlevar(List<Llevar> llevar) {
        this.llevar = llevar;
    }

}