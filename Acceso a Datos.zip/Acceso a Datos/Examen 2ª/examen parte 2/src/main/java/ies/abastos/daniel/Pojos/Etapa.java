package ies.abastos.daniel.Pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "etapa")
public class Etapa implements Serializable{
    @Id
    @Column
    private byte netapa;
    @Column
    private int km;
    @Column
    private String salida;
    @Column
    private String llegada;
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "dorsal")
    private Ciclista ciclista;

    @OneToMany(mappedBy = "etapa", cascade = CascadeType.DETACH)
    private List<Puerto> puerto = new ArrayList<Puerto>();
    @OneToMany(mappedBy = "etapa", cascade = CascadeType.DETACH)
    private List<Llevar> llevar = new ArrayList<Llevar>();

    public Etapa() {
    }

    public byte getNetapa() {
        return this.netapa;
    }

    public void setNetapa(byte netapa) {
        this.netapa = netapa;
    }

    public int getKm() {
        return this.km;
    }

    public void setKm(int km) {
        this.km = km;
    }

    public String getSalida() {
        return this.salida;
    }

    public void setSalida(String salida) {
        this.salida = salida;
    }

    public String getLlegada() {
        return this.llegada;
    }

    public void setLlegada(String llegada) {
        this.llegada = llegada;
    }

    public Ciclista getCiclista() {
        return this.ciclista;
    }

    public void setCiclista(Ciclista ciclista) {
        this.ciclista = ciclista;
    }

    public List<Puerto> getPuerto() {
        return this.puerto;
    }

    public void setPuerto(List<Puerto> puerto) {
        this.puerto = puerto;
    }

    public List<Llevar> getLlevar() {
        return this.llevar;
    }

    public void setLlevar(List<Llevar> llevar) {
        this.llevar = llevar;
    }

}