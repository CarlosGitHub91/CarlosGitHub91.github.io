public class Producto {
    private String Part_number;
    private String Descripcion;
    private String Color;
    private String Familia;
    private String Precio;

    public Producto(String Part_number, String Descripcion, String Color, String Familia, String Precio) {
        this.Part_number = Part_number;
        this.Descripcion = Descripcion;
        this.Color = Color;
        this.Familia = Familia;
        this.Precio = Precio;

    }

    public String getPart_number() {
        return Part_number;
    }

    public void setPart_number(String Part_number) {
        this.Part_number = Part_number;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getFamilia() {
        return Familia;
    }

    public void setFamilia(String Familia) {
        this.Familia = Familia;
    }

    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String Precio) {
        this.Precio = Precio;
    }
}