import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;

public class examen {
    public static void main(String[] args)
            throws SAXException, IOException, ParserConfigurationException, TransformerException, SQLException {

        File xmlFile = new File("acceso_a_datos/examen/examen.xml");
        String[] dato = { "producto" };
        String[] info = { "Part_number", "Descripcion", "Color", "Familia", "Precio" };
        ArrayList<Producto> p = examenXML.leerXml(dato, info, xmlFile);

        Scanner sc = new Scanner(System.in);
        
        /*System.out.print("Part_number: ");
        String part_number = sc.nextLine();
        System.out.print("Descripcion: ");
        String descripcion = sc.nextLine();
        System.out.print("Color: ");
        String color = sc.nextLine();
        System.out.print("Familia: ");
        String familia = sc.nextLine();
        System.out.print("Precio: ");
        String precio = sc.nextLine();
        
        Producto prod = new Producto(part_number, descripcion, color, familia,
        precio);
        p.add(prod);
        
        int cond = 0;
        boolean w = false;
        do {
        System.out.println("Quieres guardarlo como:");
        System.out.println("1: examen_new.xml");
        System.out.println("2: examen_new.txt");
        try {
        cond = sc.nextInt();
        } catch (InputMismatchException e) {
        System.out.println("Ha de ser un numero");
        sc.nextLine(); // to reset the scanner
        }
        if (cond == 1) {
        w = true;
        } else if (cond == 2) {
        w = true;
        }
        } while (!w);
        
        
        switch (cond) {
        case 1:
        xmlFile = new File("acceso_a_datos/examen/examen_new.xml");
        examenXML.escribirXml(p, xmlFile);
        break;
        case 2:
        String texto = "";
        for (Producto txt : p) {
        texto += "Part_number: " + txt.getPart_number() + "\n";
        texto += "Descripcion: " + txt.getDescripcion() + "\n";
        texto += "Color: " + txt.getColor() + "\n";
        texto += "Familia: " + txt.getFamilia() + "\n";
        texto += "Precio: " + txt.getPrecio() + "\n";
        texto +="\n";
        }
        examenText.escribirFichero("acceso_a_datos/examen/examen_new.txt", texto);
        break;
        }*/
         
        String usuario = "root";
        String password = "root";
        String url = "jdbc:mysql://localhost:3306/examen";
        conBD.conectar(usuario, password, url);

        String sentenciaSql;
        ArrayList<String[]> datos = new ArrayList<>();

        sentenciaSql = "DELETE from tienda WHERE Part_number>0";
        conBD.sentenciaSQL(sentenciaSql, null);

        sentenciaSql = "INSERT INTO tienda (Part_number,Descripcion,Color,Familia,Precio) VALUES (?,?,?,?,?)";
        for (Producto dbInsert : p) {
            datos.clear();
            String[] create = { "int", dbInsert.getPart_number() };
            String[] create1 = { "string", dbInsert.getDescripcion() };
            String[] create2 = { "string", dbInsert.getColor() };
            String[] create3 = { "string", dbInsert.getFamilia() };
            String[] create4 = { "int", dbInsert.getPrecio() };
            Collections.addAll(datos, create, create1, create2, create3, create4);
            conBD.sentenciaSQL(sentenciaSql, datos);
        }

        // sentenciaSql = "DELETE from tienda WHERE Color='blanco'";
        // conBD.sentenciaSQL(sentenciaSql, null);

        // sentenciaSql = "UPDATE tienda SET Part_number = 12 WHERE Part_number = 10";
        // conBD.sentenciaSQL(sentenciaSql, null);

        /*
         * sentenciaSql = "SELECT * FROM tienda";
         * String dbOut = "";
         * ResultSet resultado = conBD.query(sentenciaSql);
         * while (resultado.next()) {
         * dbOut += "Part_number: " + resultado.getInt(1) +
         * " / Descripcion: " + resultado.getString(2) +
         * " / Color: " + resultado.getString(3) +
         * " / Familia: " + resultado.getString(4) +
         * " / Precio: " + resultado.getString(5) + "\n";
         * }
         * conBD.cerrarQuery();
         * examenText.escribirFichero("acceso_a_datos/examen/tiendaDB.txt", dbOut);
         */

        sentenciaSql = "INSERT INTO tienda (Part_number,Descripcion,Color,Familia,Precio) VALUES (?,?,?,?,?)";
        datos.clear();

        System.out.print("Part_number: ");
        String[] create = { "int", sc.nextLine() };
        System.out.print("Descripcion: ");
        String[] create1 = { "string", sc.nextLine() };
        System.out.print("Color: ");
        String[] create2 = { "string", sc.nextLine() };
        System.out.print("Familia: ");
        String[] create3 = { "string", sc.nextLine() };
        System.out.print("Precio: ");
        String[] create4 = { "int", sc.nextLine() };
        Collections.addAll(datos, create, create1, create2, create3, create4);

        conBD.sentenciaSQL(sentenciaSql, datos);

        sentenciaSql = "UPDATE tienda SET Precio = Precio-((Precio*20)/100) WHERE Familia = 'monitores'";
        conBD.sentenciaSQL(sentenciaSql, null);
        sentenciaSql = "UPDATE tienda SET Precio = Precio-((Precio*30)/100) WHERE Familia = 'ordenadores'";
        conBD.sentenciaSQL(sentenciaSql, null);
        sentenciaSql = "UPDATE tienda SET Precio = Precio-((Precio*5)/100) WHERE Not (Familia = 'monitores' or Familia='ordenadores')";
        conBD.sentenciaSQL(sentenciaSql, null);
        sc.close(); 
    }
}
