import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class conBD {
    static Connection conexion;
    static PreparedStatement sentencia = null;
    static ResultSet resultado = null;


    public static void conectar(String usuario, String password, String url) {
        Connection conect = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conect = DriverManager.getConnection(url, usuario, password);
        } catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        conexion = conect;
    }

    public static void sentenciaSQL(String sentenciaSql, ArrayList<String[]> datos) {
        PreparedStatement sentencia = null;

        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            int p = 0;
            if (datos != null) {
                for (String[] object : datos) {
                    p++;
                    switch (object[0]) {
                        case "string":
                            sentencia.setString(p, object[1]);
                            break;
                        case "int":
                            sentencia.setInt(p, Integer.valueOf(object[1]));
                            break;
                        case "long":
                            sentencia.setLong(p, Long.valueOf(object[1]));
                            break;
                        case "double":
                            sentencia.setDouble(p, Double.valueOf(object[1]));
                            break;
                        case "float":
                            sentencia.setFloat(p, Float.valueOf(object[1]));
                            break;
                        default:
                            System.err.println("Type not found");
                            break;
                    }
                }

            }
            sentencia.executeUpdate();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        } finally {
            if (sentencia != null)
                try {
                    sentencia.close();
                } catch (SQLException sqle) {
                    sqle.printStackTrace();
                }
        }

    }

    public static ResultSet query(String sentenciaSql) {
        try {
            sentencia = conexion.prepareStatement(sentenciaSql);
            resultado = sentencia.executeQuery();
        } catch (SQLException sqle) {
            sqle.printStackTrace();
        }
        return resultado;
    }

    public static void cerrarQuery() {
        if (sentencia != null)
            try {
                sentencia.close();
                resultado.close();
            } catch (SQLException sqle) {
                sqle.printStackTrace();
            }
    }
}
