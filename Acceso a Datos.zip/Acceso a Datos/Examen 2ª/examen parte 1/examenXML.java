import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class examenXML {
    public static void escribirXml(ArrayList<Producto> elementos, File xmlFile)
            throws ParserConfigurationException, TransformerException {

        DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
        Document document = documentBuilder.newDocument();
        Element xml = document.createElement("xml");
        document.appendChild(xml);

        Element productos = document.createElement("productos");
        xml.appendChild(productos);

        for (Producto prod : elementos) {
            Element producto = document.createElement("producto");
            productos.appendChild(producto);

            Element part_number = document.createElement("Part_number");
            part_number.appendChild(document.createTextNode(prod.getPart_number()));
            producto.appendChild(part_number);

            Element descripcion = document.createElement("Descripcion");
            descripcion.appendChild(document.createTextNode(prod.getDescripcion()));
            producto.appendChild(descripcion);

            Element color = document.createElement("Color");
            color.appendChild(document.createTextNode(prod.getColor()));
            producto.appendChild(color);

            Element familia = document.createElement("Familia");
            familia.appendChild(document.createTextNode(prod.getFamilia()));
            producto.appendChild(familia);

            Element precio = document.createElement("Precio");
            precio.appendChild(document.createTextNode(prod.getPrecio()));
            producto.appendChild(precio);
        }

        // create the xml file
        // transform the DOM Object to an XML File

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource domSource = new DOMSource(document);

        StreamResult streamResult = new StreamResult(xmlFile);

        // If you use
        // StreamResult result = new StreamResult(System.out);
        // the output will be pushed to the standard output ...
        // You can use that for debugging

        transformer.transform(domSource, streamResult);

        System.out.println("Done creating XML File");
    }

    public static ArrayList<Producto> leerXml(String[] dato, String[] info, File xmlFile)
            throws ParserConfigurationException, SAXException, IOException {
        // Importa el documentoXml al formato Document
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = factory.newDocumentBuilder();
        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();
        String out = "";
        ArrayList<Producto> prod = new ArrayList<Producto>();

        // Revisa todos los datos que le pasamos
        for (String d : dato) {
            NodeList productos = doc.getElementsByTagName(d);
            out += d + "\n";

            for (int i = 0; i < productos.getLength(); i++) {
                Element elemento = (Element) productos.item(i);
                // Revisa la informacion que le pedimos
                Producto p = new Producto(
                        elemento.getElementsByTagName(info[0]).item(0).getChildNodes().item(0).getNodeValue(),
                        elemento.getElementsByTagName(info[1]).item(0).getChildNodes().item(0).getNodeValue(),
                        elemento.getElementsByTagName(info[2]).item(0).getChildNodes().item(0).getNodeValue(),
                        elemento.getElementsByTagName(info[3]).item(0).getChildNodes().item(0).getNodeValue(),
                        elemento.getElementsByTagName(info[4]).item(0).getChildNodes().item(0).getNodeValue());

                prod.add(p);
            }

        
            /*for (String string : info) {
            try {
            //Salida de cada dato
                System.out.println(elemento.getElementsByTagName(string).item(0).
                getChildNodes().item(0).getNodeValue());
            
                out += string + " = "
                + elemento.getElementsByTagName(string).item(0).getChildNodes().item(0).
                getNodeValue()
                + "\n";
                } catch (NullPointerException e) {
                }
            }
             
            plainText.escribirFichero(out, "acceso_a_datos\\examen\\inf.txt");*/

        }
        return prod;
    }
}