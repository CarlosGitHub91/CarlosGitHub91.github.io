import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class examenText {
    public static void escribirFichero(String fich, String texto) {
        FileWriter fichero = null;
        PrintWriter escritor = null;

        try {
            fichero = new FileWriter(fich);
            escritor = new PrintWriter(fichero);
            escritor.println(texto);
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            if (fichero != null) {
                try {
                    fichero.close();
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
        }
    }

    public static String leerFichero(String fich) {
        String fichero = "";
        BufferedReader buffer = null;

        try {
            buffer = new BufferedReader(new FileReader(new File(fich)));
            String linea = null;
            while ((linea = buffer.readLine()) != null) {
                fichero += linea + '\n';
            }
            fichero = fichero.substring(0, fichero.length() - 1);  

        } catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } finally {
            if (buffer != null) {
                try {
                    buffer.close();
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
        }
        return fichero;
    }
}
