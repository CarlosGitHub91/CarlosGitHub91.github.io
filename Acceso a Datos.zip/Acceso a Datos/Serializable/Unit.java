public class Unit {
    public static void [] String args(){
        System.out.println("Hola mundo");
    }
    
}
