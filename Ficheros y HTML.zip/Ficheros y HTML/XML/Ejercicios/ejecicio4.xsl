﻿<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match="horario">
        <html>
        <head>
            <title>Ejemplo1a</title>
        </head>
        <body>
            <xsl:apply-templates />
        </body>
        </html>
    </xsl:template>

    <xsl:template match="dia">
          <p>Día <xsl:value-of select="numdia"/></p>
          <xsl:apply-templates select="tarea"/>
    </xsl:template>

    <xsl:template match="tarea">
      <ul>
        <li>
          <xsl:value-of select="asignatura"/> = Prioridad: <xsl:value-of select="@prioridad"/>
          <p>De <xsl:value-of select="hora-ini"/> a <xsl:value-of select="hora-fin"/></p>
        </li>
      </ul>
    </xsl:template>
</xsl:stylesheet>