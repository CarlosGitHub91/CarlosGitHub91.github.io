﻿<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match='/'>
        <html>
        <head>
            <title>Ejercicio8</title>
        </head>
        <body>
            <p>La lista de asignaturas ordenadas alfabeticamente es:</p>
          <xsl:for-each select="horario/dia/tarea">
          <xsl:sort select="asignatura"/>
            <ul>
              <li>
                <p> <xsl:value-of select="asignatura"/></p>
              </li>
            </ul>
        </xsl:for-each>
        </body>
        </html>
    </xsl:template>
</xsl:stylesheet>