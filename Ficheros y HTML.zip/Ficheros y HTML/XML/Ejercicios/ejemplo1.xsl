﻿<?xml version="1.0" encoding="UTF-8"?> 
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
 <xsl:template match='/'>
  <html>
   <head> 
   <title>Ejercicio 1</title>
   </head> 
   <body>
    <xsl:apply-templates /> 
    </body>
     </html>
      </xsl:template> 

      <xsl:template match="dia">
       <p> 
       <xsl:value-of select="numdia" /> 
       </p>
       </xsl:template> 
       </xsl:stylesheet>