﻿<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match='/'>
        <html>
        <head>
            <title>Ejercicio9</title>
        </head>
        <body>
            <h1>Horario</h1>
          <table border="1">
            <tr bgcolor="#9acd32">
              <th>DÍA</th>
              <th>ASIGNATURA</th>
              <th>Horario</th>
              <th>Prioridad</th>
            </tr>
            <xsl:for-each select="horario/dia/tarea">
              <xsl:sort select="../numdia"/>
                <tr>
                  <td><xsl:value-of select="../numdia"/></td>
                  <td><xsl:value-of select="asignatura"/></td>
                  <td><xsl:value-of select="hora-ini"/> - <xsl:value-of select="hora-fin"/></td>
                  <td><xsl:value-of select="@prioridad"/></td>
                </tr>
            </xsl:for-each>
          </table>
        </body>
        </html>
    </xsl:template>
</xsl:stylesheet>