﻿<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match='horario'>
        <html>
        <head>
            <title>Ejercicio7</title>
        </head>
        <body>
            <p>Las asignaturas que se inician después de 15h y su prioridad no es alta son:</p>
            <xsl:apply-templates />
        </body>
        </html>
    </xsl:template>

    <xsl:template match="dia">
        <xsl:for-each select="tarea/@prioridad">
            <xsl:if test=". != 'alta'">
            <xsl:if test="../hora-fin&gt;15">
              <p>- <xsl:value-of select="../asignatura"/></p>
              </xsl:if>
            </xsl:if>
        </xsl:for-each>
    </xsl:template>
</xsl:stylesheet>