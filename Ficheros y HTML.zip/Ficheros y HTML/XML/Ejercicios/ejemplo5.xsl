﻿<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
 <xsl:template match='/'>
 <html>
 <head>
 <title>Ejemplo5 </title>
 </head>
 <body>
 <xsl:for-each select = "horario/dia/tarea">
 <xsl:if test="asignatura='Inglés'">
 <p>
 La asignatura <xsl:value-of select="asignatura"/> se da el dia <xsl:value-of select = "../numdia"/> de<xsl:value-of select = "hora-ini"/> a <xsl:value-of select = "hora-fin"/>h.
 </p>
 </xsl:if>
 </xsl:for-each>
 </body>
 </html>
 </xsl:template>
</xsl:stylesheet>