﻿<?xml version="1.0" encoding="UTF-8"?>

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

  <xsl:template match='horario'>
        <html>
        <head>
            <title>Ejercicio10</title>
        </head>
        <body>
            <h1>Horaria</h1>
          <table border="1">
            <tr bgcolor="#9acd32">
              <th>DÍA</th>
              <th>ASIGNATURA</th>
              <th>Horario</th>
              <th>Prioridad</th>
            </tr>
            <xsl:for-each select="dia/tarea">
            <xsl:sort select="../numdia"/>
            
            <tr>
              <xsl:choose>
                <xsl:when test="../numdia = 1">
                  <td>Lunes</td>
                </xsl:when>
                <xsl:when test="../numdia = 2">
                  <td>Martes</td>
                </xsl:when>
                <xsl:when test="../numdia = 3">
                  <td>Miercoles</td>
                </xsl:when>
                <xsl:when test="../numdia = 4">
                  <td>Jueves</td>
                </xsl:when>
                <xsl:when test="../numdia = 5">
                  <td>Viernes</td>
                </xsl:when>
              </xsl:choose>
              
              <td><xsl:value-of select="asignatura"/></td>
              
              <xsl:choose>
                <xsl:when test="hora-fin &lt;= 14">
                 <td>Mañanas</td>
                </xsl:when>
                <xsl:otherwise>
                <td>Tardes</td>
                </xsl:otherwise>
              </xsl:choose>
              
              <xsl:choose>
                <xsl:when test="@prioridad = 'alta'">
                  <td>Muy Importante</td>
                </xsl:when>
                <xsl:when test="@prioridad = 'media'">
                  <td>Normal</td>
                </xsl:when>
                <xsl:when test="@prioridad = 'baja'">
                  <td>Poco Importante</td>
                </xsl:when>
              </xsl:choose>
                  
                </tr>
            </xsl:for-each>
          </table>
        </body>
        </html>
    </xsl:template>
</xsl:stylesheet>