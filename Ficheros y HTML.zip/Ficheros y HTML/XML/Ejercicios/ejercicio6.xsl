﻿<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
 <xsl:template match='/'>
 <html>
 <head>
 <title>Ejemplo6</title>
 </head>
 <body>
 <p>La asignaturas que se incian siempre antes de las 13 h son: </p>
 <xsl:for-each select = "horario/dia/tarea">
 <xsl:if test="hora-ini &lt; 13">
 <p>- <xsl:value-of select="asignatura"/> </p>
 </xsl:if>
 </xsl:for-each>
 </body>
 </html>
 </xsl:template>
</xsl:stylesheet>