
        <script>
            console.log("Hola Mundo desde consola de Chrome");
        </script>
  
